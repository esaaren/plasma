import os
import yaml
import json
from airflow.configuration import expand_env_var

__DEV_BUCKET = 'edap-dev'
__PROD_BUCKET = 'edap-prod'
__DEV_DF_BUCKET = 'edap-dataflow'
__PROD_DF_BUCKET = 'edap-dataflow-prod'
__DEV_TF_BUCKET = 'edap-transform-queries-dev'
__PROD_TF_BUCKET = 'edap-transform-queries'
__PROD_PROJECT = 'twm-edap-prod-1802'
__DEV_PROJECT = 'twm-edap-dev-1802'


def project():
    if isDevelopmentEnvironment():
        return __DEV_PROJECT
    else:
        return __PROD_PROJECT


def isDevelopmentEnvironment():
    if 'ENV' not in os.environ:
        return True
    else:
        ENV = expand_env_var(os.environ['ENV'])
        if ENV == 'production':
            return False
        else:
            return True


def gcs_bucket():
    if isDevelopmentEnvironment():
        return __DEV_BUCKET
    else:
        return __PROD_BUCKET


def gcs_dataflow_bucket():
    if isDevelopmentEnvironment():
        return __DEV_DF_BUCKET
    else:
        return __PROD_DF_BUCKET


def gcs_transform_bucket():
    if isDevelopmentEnvironment():
        return __DEV_TF_BUCKET
    else:
        return __PROD_TF_BUCKET


def getEmailList():
    if isDevelopmentEnvironment():
        return ['rkorra@totalwine.com', 'ryan.dsouza@slalom.com', 'yasneen.ashroff@slalom.com']
    else:
        return ['EDAPTeam@totalwine.com', 'EDAP-P3@totalwine.com']


def datalake_metadata(area, szone, source_name, table_name, file_format):
    """
        Compose location for metadata file
    """
    metadata = ('metadata' + '/' +
                source_name + '_' +
                table_name + '_' +
                '{job_id}' + '_' +
                'metadata')
    return metadata


def datalake_path(area, source_name, szone, table_name):
    return area + chr(47) + szone + chr(47) + \
        source_name + chr(47) + table_name + chr(47) + '{{ts_nodash}}' + chr(47)


def datalake_schema(area, szone, source_name, table_name, file_format):
    """
        Compose location for bq schema file
    """
    schema = (datalake_path(area, source_name, szone, table_name) +
              schema_filename(table_name))

    return schema


def schema_filename(table_name):
    return table_name + '_' + 'bqschema'


def datalake_filename(area, szone, source_name, table_name, file_format):
    """
        Compose datalake file name and path based on area, szone, source name
        and table name
    """
    filename = (datalake_path(area, source_name, szone, table_name) +
                table_name + '.' + file_format)

    return filename


def read_config(szones_config_file='/twm_ingestion_szones.yaml'):
    """
    Converts the configuration file into api acl format
    """
    szones_cfg = yaml.load(szones_config_file)
    szone_acls = {}
    for szone in szones_cfg['szones']:
        acl_list = []
        for acls in szones_cfg['szones'][szone]:
            acl_list.append(
                {
                    'entity': szones_cfg['szones'][szone][acls]['entity'] +
                    '-' + szones_cfg['szones'][szone][acls]['name'],
                    'role': szones_cfg['szones'][szone][acls]['access']
                }
            )
        szone_acls[szone] = acl_list
    return szone_acls


def create_staging_schema(**context):
    """
        Accepts task context which contains the existing schema of a table in JSON format
        Appends the additional CDC columns used in the staging tables
        Overwrites the XCOM variable with the modified schema
    :param context:
    """
    existing_table_schema = context["task_instance"].xcom_pull(
        task_ids='gcs_download_schema_' + context["params"]["source_table"], key='TABLE_SCHEMA')
    table_schema = json.loads(existing_table_schema.decode('utf-8'))
    # append start date to track insertion
    table_schema.append({
        "mode": "REQUIRED",
        "name": "CDC_START_DATE",
        "type": "DATETIME"
    })
    # append end date to track when record became stale
    table_schema.append({
        "mode": "NULLABLE",
        "name": "CDC_END_DATE",
        "type": "DATETIME"
    })
    # append flag to track which record is current
    table_schema.append({
        "mode": "REQUIRED",
        "name": "CURRENT_FLAG",
        "type": "BOOL"
    })
    # append flag to track which airflow run created this data
    table_schema.append({
        "mode": "REQUIRED",
        "name": "JOB_ID",
        "type": "STRING"
    })

    context["task_instance"].xcom_push(key='TABLE_SCHEMA', value=table_schema)
