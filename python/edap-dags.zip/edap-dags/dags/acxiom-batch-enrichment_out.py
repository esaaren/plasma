import yaml
from datetime import timedelta, datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.sensors import ExternalTaskSensor
from airflow.contrib.operators.bigquery_to_gcs import BigQueryToCloudStorageOperator
from airflow.contrib.operators.file_to_gcs import FileToGoogleCloudStorageOperator
from airflow.contrib.operators.gcs_download_operator import GoogleCloudStorageDownloadOperator
from airflow.contrib.operators.sftp_operator import SFTPOperator, SFTPOperation
from twm_plugin import BigQueryOperator
from twm_plugin.operators.gcs_to_gcs import GoogleCloudStorageToGoogleCloudStorageOperator
from twm_plugin.operators.pgp_operator import TWM_PGPEncryptOperator
from twm_plugin.sensors.gcs_sensor import GoogleCloudStorageObjectSensor
# from twm_plugin.sensors.sftp_sensor import SFTPSensor
from UDF import utils

# This DAG gets data out of a Cloud Dataflow produced extract into an SFTP
# server for Acxiom enrichment services to provide additional information

default_args = {
    'owner': 'edap',
    'depends_on_past': False,
    'email': utils.getEmailList(),
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 100,
    'retry_delay': timedelta(minutes=10),
    'start_date': datetime(2018, 10, 3)
}
dag = DAG('acxiom_enrichment_out',
          default_args=default_args,
          schedule_interval='@once')

# acxiom_enrichment = ['daily', 'ibe', 'refresh']
acxiom_enrichment = ['daily', 'refresh']
for service in acxiom_enrichment:
    if service == 'daily':
        yaml_file = yaml.load(
            open('/airflow/dags/configs/acxiom_batch_enrichment_out.yaml'))
        # column_names = yaml_file['column_names']
        # query = "SELECT " + column_names + \
        # " FROM `twm-edap-dev-1802.devtest.CDI_REQUESTS_10_10_2018`"
        query = yaml_file["query"]
    elif service == 'ibe':
        yaml_file = yaml.load(
            open('/airflow/dags/configs/infobase_batch_enrichment_out.yaml'))
        # column_names = yaml_file['column_names']
        # query = "SELECT " + column_names + \
        #     " FROM `twm-edap-dev-1802.devtest.IBE_20181011`"
        query = yaml_file["query"]
        query = query.replace("@DAYS_TO_WAIT", yaml_file['DAYS_TO_WAIT'])
    elif service == 'refresh':
        yaml_file = yaml.load(
            open('/airflow/dags/configs/refresh_batch_enrichment_out.yaml'))
        # query = "SELECT SOURCE_EKEY, FULL_NAME, EMAIL_ADDR, PHONE_NUM, ADDRESS1, ADDRESS2, URBAN_DISTRICT, CITY, STATE, COUNTRY, ZIP, ZIP4" + \
        #     " FROM `twm-edap-dev-1802.devtest.ACX_REFRESH_REQS_20181003`"
        query = yaml_file['query']
        query = query.replace("@DAYS_TO_WAIT", yaml_file['DAYS_TO_WAIT'])

    PROJECT = utils.project()
    GCP_CONN_ID = yaml_file['GCP_CONN_ID']
    BQ_CONN_ID = yaml_file['BQ_CONN_ID']
    SFTP_CONN_ID = yaml_file['SFTP_CONN_ID']
    bucket = yaml_file['bucket']
    GCS_path = yaml_file['GCS_path']
    prefix = yaml_file['prefix']
    composite_filename = yaml_file['composite_filename']
    local_filename = yaml_file['local_filename']
    schema = yaml_file['schema']
    column_names = yaml_file['column_names']
    column_names2 = yaml_file['column_names2']
    requests_tbl = yaml_file['requests_tbl']
    requests_tmp_tbl = yaml_file['requests_tmp_tbl']
    encrypted_file_location = yaml_file['encrypted_file_location']
    unencrypted_file_location = yaml_file['unencrypted_file_location']
    control_card_file_location = yaml_file['control_card_file_location']
    sftp_encrypted_file_location = yaml_file['sftp_encrypted_file_location']
    sftp_control_card_file_location = yaml_file['sftp_control_card_file_location']
    gcs_unencrypted_file_location = yaml_file['gcs_unencrypted_file_location']
    gcs_control_card_file_location = yaml_file['gcs_control_card_file_location']
    recipients_fingerprint = yaml_file['recipients_fingerprint']
    requests_tbl_dest = PROJECT + "." + requests_tbl['dataset_table']
    requests_tmp_tbl_dest = PROJECT + "." + requests_tmp_tbl['dataset_table']

    # wait_for_dataflow = ExternalTaskSensor(
    #     task_id='wait_for_customer_matching',
    #     external_dag_id='customer_matching_dataflow',
    #     external_task_id='customer_matching_job_sensor',
    #     execution_delta=None,  # Same day as today
    #     dag=dag)

    # Append the results of the view into Requests table
    write_to_requests_tbl = BigQueryOperator(
        task_id='write_to_requests_tbl_' + service,
        bigquery_conn_id=BQ_CONN_ID,
        use_legacy_sql=False,
        write_disposition=requests_tbl['write_disposition'],
        allow_large_results=True,
        # time_partitioning={"field": 'JOB_RUN_DATE'},
        bql=query,
        destination_dataset_table=requests_tbl_dest,
        schema_fields=schema,
        dag=dag
    )

    # Write the results of the view into temp table
    write_to_tmp_tbl = BigQueryOperator(
        task_id='write_to_tmp_tbl_' + service,
        bigquery_conn_id=BQ_CONN_ID,
        use_legacy_sql=False,
        write_disposition=requests_tmp_tbl['write_disposition'],
        allow_large_results=True,
        # time_partitioning={"field": 'JOB_RUN_DATE'},
        bql=query,
        destination_dataset_table=requests_tmp_tbl_dest,
        schema_fields=schema,
        dag=dag
    )

    bq_to_gcs = BigQueryToCloudStorageOperator(
        task_id='export_acxiom_extract_to_gcs_' + service,
        source_project_dataset_table=requests_tmp_tbl_dest,
        destination_cloud_storage_uris=[GCS_path + prefix + '.csv'],
        field_delimiter='|',
        # compression='',
        export_format='CSV',
        print_header=False,
        bigquery_conn_id='gbq',
        dag=dag)

    create_composite_extract_file = GoogleCloudStorageToGoogleCloudStorageOperator(
        task_id='create_composite_extract_file_' + service,
        google_cloud_storage_conn_id=GCP_CONN_ID,
        destination_bucket=bucket,
        destination_object=composite_filename,
        compose=True,
        prefix=prefix,
        dag=dag)

    wait = GoogleCloudStorageObjectSensor(
        task_id='acxiom_extract_file_sensor_' + service,
        bucket=bucket,
        object=composite_filename,
        google_cloud_conn_id=GCP_CONN_ID,
        poke_interval=60,
        dag=dag)

    download = GoogleCloudStorageDownloadOperator(
        task_id='download_acxiom_extract_' + service,
        bucket=bucket,
        object=composite_filename,
        filename=local_filename,
        google_cloud_storage_conn_id=GCP_CONN_ID,
        dag=dag)

    # Bash command to create the control card xml file
    bash_cmd = "wc=($(wc -l " + local_filename + ")) && num_lines=${wc[0]} && printf \"" + \
        "<ControlFile>\n" +\
        "  <EnvironmentVariables>\n" + \
        "      <Param name='DC_" + service.upper() + "_IN' value='tw_to_acxiom_" + service + "_01_{{ ds_nodash }}.txt.pgp'/>\n" +\
        "      <Param name='NUM_RECS' value='$num_lines'/>\n" +\
        "      <Param name='FILE_ID' value='01'/>\n" +\
        "      <Param name='SOURCE_ID' value='" + service + "'/>\n" +\
        "      <Param name='DATE' value='{{ ds_nodash }}'/>\n" +\
        "  </EnvironmentVariables>\n" +\
        "</ControlFile>\" > " + \
        control_card_file_location

    create_control_card = BashOperator(
        task_id='create_control_card_' + service,
        # depends_on_past=False,
        bash_command=bash_cmd,
        dag=dag)

    # Bash command to add the column headers to the beginning of the extract file
    bash_cmd2 = "echo '" + column_names2 + "' | cat - " + \
        local_filename + " > " + unencrypted_file_location

    add_column_header = BashOperator(
        task_id='add_column_header_' + service,
        # depends_on_past=True,
        bash_command=bash_cmd2,
        dag=dag)

    encrypt = TWM_PGPEncryptOperator(
        task_id='encrypt_acxiom_extract_' + service,
        src_unencrypted_file_location=unencrypted_file_location,
        recipients_fingerprint=recipients_fingerprint,
        dest_encrypted_file_location=encrypted_file_location,
        dag=dag)

    upload_acxiom_extract_gcs = FileToGoogleCloudStorageOperator(
        task_id='upload_acxiom_extract_to_gcs_' + service,
        src=unencrypted_file_location,
        dst=gcs_unencrypted_file_location,
        bucket=bucket,
        google_cloud_storage_conn_id=GCP_CONN_ID,
        dag=dag)

    upload_acxiom_extract_sftp = SFTPOperator(
        task_id='upload_acxiom_extract_to_sftp_' + service,
        ssh_conn_id=SFTP_CONN_ID,
        local_filepath=encrypted_file_location,
        remote_filepath=sftp_encrypted_file_location,
        operation=SFTPOperation.PUT,
        dag=dag)

    upload_ctl_card_gcs = FileToGoogleCloudStorageOperator(
        task_id='upload_control_card_to_gcs_' + service,
        src=control_card_file_location,
        dst=gcs_control_card_file_location,
        bucket=bucket,
        google_cloud_storage_conn_id=GCP_CONN_ID,
        dag=dag)

    upload_ctl_card_sftp = SFTPOperator(
        task_id='upload_control_card_to_sftp_' + service,
        ssh_conn_id='acxiom_sftp_out',
        local_filepath=control_card_file_location,
        remote_filepath=sftp_control_card_file_location,
        operation=SFTPOperation.PUT,
        dag=dag)

    # Bash command to remove local unencrypted file
    post_process_1 = BashOperator(
        task_id='delete_local_unencrypted_acxiom_extract_' + service,
        # depends_on_past=False,
        bash_command="rm " + unencrypted_file_location,
        dag=dag)

    # Bash command to remove local encrypted file
    post_process_2 = BashOperator(
        task_id='delete_local_encrypted_acxiom_extract_' + service,
        # depends_on_past=False,
        bash_command="rm " + encrypted_file_location,
        dag=dag)

    post_process_5 = GoogleCloudStorageToGoogleCloudStorageOperator(
        task_id='delete_export_parts_' + service,
        google_cloud_storage_conn_id=GCP_CONN_ID,
        source_bucket=bucket,
        prefix=prefix,
        delete=True,
        dag=dag)

    # Bash command to remove local temp file
    post_process_6 = BashOperator(
        task_id='delete_local_temp_acxiom_extract_' + service,
        # depends_on_past=False,
        bash_command="rm " + local_filename,
        dag=dag)

    # Bash command to remove local control card file
    post_process_3 = BashOperator(
        task_id='delete_local_control_card_file_' + service,
        # depends_on_past=False,
        bash_command="rm " + control_card_file_location,
        trigger_rule='all_done',
        dag=dag)

    # wait_for_dataflow >>
    write_to_tmp_tbl >> bq_to_gcs >> \
        create_composite_extract_file >> wait >> download >>  \
        create_control_card >> add_column_header >> encrypt >> \
        upload_acxiom_extract_sftp >> upload_ctl_card_sftp

    upload_acxiom_extract_sftp >> upload_acxiom_extract_gcs >> \
        post_process_1 >> post_process_2 >> post_process_6 >> post_process_5
    upload_ctl_card_sftp >> upload_ctl_card_gcs >> post_process_3
