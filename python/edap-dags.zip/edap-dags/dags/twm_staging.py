import os
from airflow import DAG
import yaml
from airflow.contrib.operators.gcs_download_operator import GoogleCloudStorageDownloadOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.sensors import ExternalTaskSensor

from twm_plugin import (
    BigQueryOperator,
    BigQueryCreateEmptyTableOperator)
from UDF import utils
from datetime import timedelta
from airflow.configuration import expand_env_var

from twm_plugin.sensors.bigquery_job_sensor import BigQueryJobSensor


def task_factory(dag, final_task, task_yaml):
    """
        Create TWM custom Airflow tasks from yaml configuration
    """
    # Options that apply for all tasks
    source_table = task_yaml['source_table']
    primary_keys = task_yaml['primary_keys']
    primary_keys_string = ''
    for _, key in enumerate(primary_keys):
        primary_keys_string += ''' AND t.''' + key + ''' = s.''' + key

    # Environment Setup
    # ENV = expand_env_var('development')
    PROJECT = utils.project()
    dest_bucket = utils.gcs_bucket()

    # Options specific for this operator
    dest_area = task_yaml['dest_area']
    dest_szone = task_yaml['dest_szone']
    dest_sourcesys = task_yaml['dest_sourcesys']
    dest_dataset = task_yaml['dest_dataset']
    dest_export_format = task_yaml['dest_export_format']
    skip_backfill = task_yaml.get('skip_backfill', False)

    # Compose schema file name based on configuration
    schema = utils.datalake_schema(
        dest_area,
        dest_szone,
        dest_sourcesys,
        dest_dataset,
        dest_export_format)

    wait_for_raw = ExternalTaskSensor(
        task_id='wait_for_raw_' + source_table + '_table_load',
        external_dag_id=dag_name + '_bq_raw',
        external_task_id='bq_raw_load_' + source_table,
        execution_delta=None,  # Same day as today
        poke_interval=60,
        pool='staging_sensor_pool',
        dag=dag)
    gcs_download_schema = GoogleCloudStorageDownloadOperator(
        task_id='gcs_download_schema_' + source_table,
        google_cloud_storage_conn_id='gcs',
        bucket=dest_bucket,
        object=utils.datalake_path(dest_area, dest_sourcesys, dest_szone, dest_dataset) + utils.schema_filename(dest_dataset),
        store_to_xcom_key='TABLE_SCHEMA',
        dag=dag
    )
    gcs_create_staging_schema = PythonOperator(
        task_id='gcs_create_staging_schema_' + source_table,
        provide_context=True,
        python_callable=utils.create_staging_schema,
        params={"source_table": source_table},
        dag=dag
    )
    bq_create_empty_staging_table = BigQueryCreateEmptyTableOperator(
        task_id='bq_create_empty_staging_table_' + source_table,
        project_id=PROJECT,
        dataset_id='staging',
        table_id=dest_sourcesys + '_' + dest_dataset,
        schema_fields='{{ ti.xcom_pull(task_ids="gcs_create_staging_schema_' + source_table + '", key="TABLE_SCHEMA") }}',
        bigquery_conn_id='gbq',
        time_partitioning={'field': 'JOB_RUN_DATE'},
        dag=dag
    )
    bq_clear_partition = BigQueryOperator(
        task_id='bq_clear_partition_' + source_table,
        bigquery_conn_id='gbq',
        use_legacy_sql=False,
        write_disposition='WRITE_APPEND',
        allow_large_results=True,
        wait_for_downstream=True,
        bql='''
            DELETE
            FROM `''' + PROJECT + '''.staging.''' + dest_sourcesys + '_' + dest_dataset + '''`
            WHERE
                JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
        dag=dag
    )
    bq_write_to_staging = BigQueryOperator(
        task_id='bq_write_to_staging_' + source_table,
        bigquery_conn_id='gbq',
        use_legacy_sql=False,
        write_disposition='WRITE_APPEND',
        allow_large_results=True,
        time_partitioning={"field": 'JOB_RUN_DATE'},
        bql='''
            SELECT
            CAST("{{ ds }}" as DATETIME) as CDC_START_DATE,
            CAST(NULL as DATETIME) as CDC_END_DATE,
            True as CURRENT_FLAG,
            "{{ ti.dag_id + '.' + ti.task_id + '.' }}{{ ti.job_id }}" as JOB_ID,
            t.*
            FROM `''' + PROJECT + '''.raw.''' + dest_sourcesys + '_' + dest_dataset + '''` t
            WHERE
                t.JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
        destination_dataset_table=PROJECT + '.staging.' + dest_sourcesys + '_' + dest_dataset,
        store_to_xcom_key='STAGING_WRITE_JOB_ID',
        check_job_status=False,
        schema_object=schema,
        pool='bq_long_task_pool_staging',
        dag=dag
    )
    wait_for_bq_write = BigQueryJobSensor(
        task_id='wait_for_bq_write_' + source_table,
        project_id=PROJECT,
        bigquery_conn_id='gbq',
        job_id='{{ ti.xcom_pull(task_ids="bq_write_to_staging_' + source_table + '", key="STAGING_WRITE_JOB_ID") }}',
    )
    if not skip_backfill:
        bq_backfill_updated_records = BigQueryOperator(
            task_id='bq_backfill_updated_records_' + source_table,
            bigquery_conn_id='gbq',
            use_legacy_sql=False,
            write_disposition='WRITE_APPEND',
            allow_large_results=True,
            wait_for_downstream=True,
            time_partitioning={"field": 'JOB_RUN_DATE'},
            bql='''
                SELECT
                CASE
                  WHEN CDC_END_DATE IS NOT NULL THEN CDC_END_DATE
                  ELSE CAST("{{ ds }}" as DATETIME)
                END AS CDC_END_DATE,
                CAST("{{ ds }}" as DATE) as JOB_RUN_DATE,
                False AS CURRENT_FLAG,
                "{{ ti.dag_id + '.' + ti.task_id + '.' }}{{ ti.job_id }}" as JOB_ID,
                t.* EXCEPT (JOB_RUN_DATE, CDC_END_DATE, CURRENT_FLAG, JOB_ID)
                FROM `''' + PROJECT + '''.staging.''' + dest_sourcesys + '_' + dest_dataset + '''` t
                WHERE
                    t.JOB_RUN_DATE = CAST("{{ yesterday_ds }}" as DATE)
                    AND EXISTS
                    (SELECT * FROM `''' + PROJECT + '''.staging.''' + dest_sourcesys + '_' + dest_dataset + '''` s
                        WHERE s.JOB_RUN_DATE = CAST("{{ ds }}" as DATE) ''' + primary_keys_string +
                    ''' AND s.CDC_START_DATE != t.CDC_START_DATE''' +
                ''' ) ''',
            destination_dataset_table=PROJECT + '.staging.' + dest_sourcesys + '_' + dest_dataset,
            store_to_xcom_key='STAGING_BACKFILL_UPDATED_JOB_ID',
            check_job_status=False,
            pool='bq_long_task_pool_staging',
            dag=dag
        )
        wait_for_bq_updated_backfill = BigQueryJobSensor(
            task_id='wait_for_bq_updated_backfill_' + source_table,
            project_id=PROJECT,
            bigquery_conn_id='gbq',
            wait_for_downstream=True,
            job_id='{{ ti.xcom_pull(task_ids="bq_backfill_updated_records_' + source_table + '", key="STAGING_BACKFILL_UPDATED_JOB_ID") }}',
        )
        if dag.catchup:
            bq_backfill_non_updated_records = BigQueryOperator(
                task_id='bq_backfill_non_updated_records_' + source_table,
                bigquery_conn_id='gbq',
                use_legacy_sql=False,
                write_disposition='WRITE_APPEND',
                allow_large_results=True,
                wait_for_downstream=True,
                time_partitioning={"field": 'JOB_RUN_DATE'},
                bql='''
                    SELECT
                    CAST("{{ ds }}" as DATE) as JOB_RUN_DATE,
                    "{{ ti.dag_id + '.' + ti.task_id + '.' }}{{ ti.job_id }}" as JOB_ID,
                    t.* EXCEPT (JOB_RUN_DATE, JOB_ID)
                    FROM `''' + PROJECT + '''.staging.''' + dest_sourcesys + '_' + dest_dataset + '''` t
                    WHERE
                        t.JOB_RUN_DATE = CAST("{{ yesterday_ds }}" as DATE)
                        AND NOT EXISTS
                        (SELECT * FROM `''' + PROJECT + '''.staging.''' + dest_sourcesys + '_' + dest_dataset + '''` s
                            WHERE s.JOB_RUN_DATE = CAST("{{ ds }}" as DATE) ''' + primary_keys_string +
                        ''' AND s.CDC_START_DATE = t.CDC_START_DATE''' +
                        ''' ) ''',
                destination_dataset_table=PROJECT + '.staging.' + dest_sourcesys + '_' + dest_dataset,
                store_to_xcom_key='STAGING_BACKFILL_NON_UPDATED_JOB_ID',
                check_job_status=False,
                pool='bq_long_task_pool_staging',
                dag=dag
            )
            wait_for_bq_non_updated_backfill = BigQueryJobSensor(
                task_id='wait_for_bq_non_updated_backfill_' + source_table,
                project_id=PROJECT,
                bigquery_conn_id='gbq',
                job_id='{{ ti.xcom_pull(task_ids="bq_backfill_non_updated_records_' + source_table + '", key="STAGING_BACKFILL_NON_UPDATED_JOB_ID") }}',
            )

    if skip_backfill and dag.catchup:
        bq_invalidate_historical_records = BigQueryOperator(
            task_id='bq_invalidate_historical_records_' + source_table,
            bigquery_conn_id='gbq',
            use_legacy_sql=False,
            write_disposition='WRITE_APPEND',
            allow_large_results=True,
            wait_for_downstream=True,
            bql='''
            UPDATE `''' + PROJECT + '''.staging.''' + dest_sourcesys + '_' + dest_dataset + '''` t
            SET t.CURRENT_FLAG = FALSE
            WHERE
            t.CURRENT_FLAG = TRUE
            AND
            t.JOB_RUN_DATE < CAST("{{ ds }}" as DATE)
            AND EXISTS
            (SELECT * FROM `''' + PROJECT + '''.staging.''' + dest_sourcesys + '_' + dest_dataset + '''` s
                WHERE s.JOB_RUN_DATE = CAST("{{ ds }}" as DATE) ''' + primary_keys_string +
            ''' ) ''',
            dag=dag
        )

    # Wait for the RAW load DAGs to complete
    gcs_download_schema.set_upstream(wait_for_raw)
    # Always make sure the BQ schema update task depends on the schema download task
    gcs_create_staging_schema.set_upstream(gcs_download_schema)
    # Always make sure the BQ create staging table task depends on the create staging schema task
    bq_create_empty_staging_table.set_upstream(gcs_create_staging_schema)
    # CLear the partition we are about to insert data into, in case of previously failed task
    bq_clear_partition.set_upstream(bq_create_empty_staging_table)
    # Always make sure the BQ staging write task depends on the gcs_create_staging_schema`
    bq_write_to_staging.set_upstream(bq_clear_partition)
    # Wait for the BQ job to finish
    wait_for_bq_write.set_upstream(bq_write_to_staging)

    if not skip_backfill:
        # Backfill the old version of records that have been updated
        bq_backfill_updated_records.set_upstream(wait_for_bq_write)
        # Wait for the BQ job to finish
        wait_for_bq_updated_backfill.set_upstream(bq_backfill_updated_records)
        # Only run the backfill task if the table is incremental (catchup = true)
        if dag.catchup:
            bq_backfill_non_updated_records.set_upstream(wait_for_bq_updated_backfill)
            wait_for_bq_non_updated_backfill.set_upstream(bq_backfill_non_updated_records)
            final_task.set_upstream(wait_for_bq_non_updated_backfill)
        else:
            final_task.set_upstream(wait_for_bq_updated_backfill)
        # if ENV == 'production':
            # bq_cleanup_old_partitions.set_upstream(wait_for_bq_updated_backfill)
    if skip_backfill and dag.catchup:
        bq_invalidate_historical_records.set_upstream(wait_for_bq_write)
        final_task.set_upstream(bq_invalidate_historical_records)
    else:
        final_task.set_upstream(wait_for_bq_write)


def map_to_task(dag, task_yaml, final_task):
    """
    Create an Airflow Task object from yaml configuration
    """
    new_task = task_factory(dag, final_task, task_yaml)
    return new_task


def map_to_dag(dag_name, dag_yaml):
    """
        Create an Airflow DAG object from yaml configuration file
    """
    description = dag_yaml.get('description', "")
    schedule_interval = dag_yaml.get('schedule_interval', "")
    if 'staging_start_date' in dag_yaml:
        start_date = dag_yaml.get('staging_start_date', "")
    else:
        start_date = dag_yaml.get('start_date', "")
    end_date = dag_yaml.get('end_date', "")
    catchup = dag_yaml.get('catchup', False)
    max_active_dags = dag_yaml.get('max_active_dags', 32)

    default_args = {
        'owner': 'edap',
        'depends_on_past': False,
        'email': utils.getEmailList(),
        'email_on_failure': True,
        'email_on_retry': True,
        'retries': 2,
        'retry_delay': timedelta(minutes=3),
    }

    if end_date != "":
        dag = DAG(
            dag_name + '_bq_staging',
            description=description,
            schedule_interval=schedule_interval,
            start_date=start_date,
            end_date=end_date,
            catchup=catchup,
            max_active_runs=max_active_dags,
            default_args=default_args)
    else:
        dag = DAG(
            dag_name + '_bq_staging',
            description=description,
            schedule_interval=schedule_interval,
            start_date=start_date,
            catchup=catchup,
            max_active_runs=max_active_dags,
            default_args=default_args)

    # Create a task which all generated tasks will converge to so completion can easily be checked
    dag_complete = DummyOperator(task_id='dag_complete', dag=dag)
    # Iterate through the sub-items on a DAG and create tasks
    for task_name in dag_yaml["tasks"]:
        map_to_task(dag, dag_yaml["tasks"][task_name], dag_complete)
    return dag


# Load yaml file
if 'AIRFLOW_HOME' not in os.environ:
    AIRFLOW_HOME = expand_env_var('~/airflow')
else:
    AIRFLOW_HOME = expand_env_var(os.environ['AIRFLOW_HOME'])

AIRFLOW_DAGS_FOLDER = AIRFLOW_HOME + '/dags'

# Read configuration file for DAGs
DIRECTORY = AIRFLOW_DAGS_FOLDER + '/sources'
yaml_string = ''
# loop through all files in the sources dir
for filename in os.listdir(AIRFLOW_DAGS_FOLDER + '/sources'):
    if "historical" not in filename:
        with open(DIRECTORY + '/' + filename, "r") as infile:
            # append them to the dags file object
            yaml_string += infile.read()
ingestion_dags = yaml.load(yaml_string)

# Iterate through the first level and create DAGs
if ingestion_dags:
    for dag_name in ingestion_dags:
        dag = map_to_dag(dag_name, ingestion_dags[dag_name])
        globals()[dag_name] = dag
