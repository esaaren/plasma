import os
from airflow import DAG
import yaml
from airflow.operators.dummy_operator import DummyOperator

from UDF import utils
from airflow.operators.sensors import ExternalTaskSensor
from twm_plugin import (
    BigQueryOperator,
    BigQueryCreateEmptyTableOperator,
    TWM_GoogleCloudStorageToBigQueryOperator)
from datetime import timedelta
from airflow.configuration import expand_env_var


def task_factory(dag, task_yaml):
    """
        Create TWM custom Airflow tasks from yaml configuration
    """
    # Options that apply for all tasks
    source_table = task_yaml['source_table']
    primary_keys = task_yaml['primary_keys']
    primary_keys_string = ''
    for _, key in enumerate(primary_keys):
        primary_keys_string += ''' AND t.''' + key + ''' = s.''' + key

    # Environment Setup
    # ENV = expand_env_var('development')
    PROJECT = utils.project()
    dest_bucket = utils.gcs_bucket()

    # Options specific for this operator
    dest_area = task_yaml['dest_area']
    dest_szone = task_yaml['dest_szone']
    dest_sourcesys = task_yaml['dest_sourcesys']
    dest_dataset = task_yaml['dest_dataset']
    dest_export_format = task_yaml['dest_export_format']

    # Compose schema file name based on configuration
    schema = utils.datalake_schema(
        dest_area,
        dest_szone,
        dest_sourcesys,
        dest_dataset,
        dest_export_format)

    filename = utils.datalake_filename(
        dest_area,
        dest_szone,
        dest_sourcesys,
        dest_dataset,
        dest_export_format)

    if utils.isDevelopmentEnvironment():
        # if dev environment, use a DummyOperator because ingestion doesn't happen on dev instance
        dummy_wait = DummyOperator(task_id='fake_wait_for_ingestion_' + source_table,
                                   dag=dag)  # This is run instead of wait task on dev env
    else:
        wait_for_ingestion = ExternalTaskSensor(
            task_id='wait_for_' + source_table + '_table_load',
            external_dag_id=dag_name + '_gcs',
            external_task_id=source_table + '_table_load',
            execution_delta=None,  # Same day as today
            poke_interval=60,
            pool='raw_sensor_pool',
            dag=dag)

    bq_create_empty_raw_table = BigQueryCreateEmptyTableOperator(
        task_id='bq_create_empty_raw_table_' + source_table,
        project_id=PROJECT,
        dataset_id='raw',
        table_id=dest_sourcesys + '_' + dest_dataset,
        gcs_schema_object='gs://' + dest_bucket + '/' + schema,
        google_cloud_storage_conn_id='gcs',
        bigquery_conn_id='gbq',
        time_partitioning={'field': 'JOB_RUN_DATE'},
        dag=dag
    )
    bq_clear_partition = BigQueryOperator(
        task_id='bq_clear_partition_' + source_table,
        bigquery_conn_id='gbq',
        use_legacy_sql=False,
        write_disposition='WRITE_APPEND',
        allow_large_results=True,
        wait_for_downstream=True,
        sql='''
            DELETE
            FROM `''' + PROJECT + '''.raw.''' + dest_sourcesys + '_' + dest_dataset + '''`
            WHERE
                JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
        dag=dag
    )
    bq_load_task = TWM_GoogleCloudStorageToBigQueryOperator(
        task_id='bq_raw_load_' + source_table,
        bucket=dest_bucket,
        source_objects=[filename],
        destination_project_dataset_table=PROJECT + '.raw.' + dest_sourcesys + '_' + dest_dataset,
        source_format='CSV',
        create_disposition='CREATE_IF_NEEDED',
        schema_object=schema,
        field_delimiter='|',
        quote_character='"',
        ignore_unknown_values=False,
        allow_quoted_newlines=True,
        allow_jagged_rows=False,
        bigquery_conn_id='gbq',
        google_cloud_storage_conn_id='gcs',
        write_disposition='WRITE_APPEND',
        time_partitioning={"field": 'JOB_RUN_DATE'},
        skip_leading_rows=1,
        dag=dag
    )

    if utils.isDevelopmentEnvironment():
        # if dev environment, use a DummyOperator because ingestion doesn't happen on dev instance
        bq_create_empty_raw_table.set_upstream(dummy_wait)
    else:
        # Wait for the ingestion DAGs to complete then create table if it doesn't exist
        bq_create_empty_raw_table.set_upstream(wait_for_ingestion)
    bq_clear_partition.set_upstream(bq_create_empty_raw_table)  # Clear the partition before writing to it
    # bq_load_task ingests the data from CSV using the schema in the
    # same folder (Note that this will fail if the schema has changed)
    bq_load_task.set_upstream(bq_clear_partition)


def map_to_dag(dag_name, dag_yaml):
    """
        Create an Airflow DAG object from yaml configuration file
    """
    description = dag_yaml.get('description', "")
    schedule_interval = dag_yaml.get('schedule_interval', "")
    start_date = dag_yaml.get('start_date', "")
    end_date = dag_yaml.get('end_date', "")
    catchup = dag_yaml.get('catchup', False)
    max_active_dags = 32  # We don't need to throttle this DAG

    default_args = {
        'owner': 'edap',
        'email': utils.getEmailList(),
        'email_on_failure': True,
        'email_on_retry': True,
        'depends_on_past': False,
        'retries': 2,
        'retry_delay': timedelta(minutes=3),
    }

    if end_date != "":
        dag = DAG(
            dag_name + '_bq_raw',
            description=description,
            schedule_interval=schedule_interval,
            start_date=start_date,
            end_date=end_date,
            catchup=catchup,
            max_active_runs=max_active_dags,
            default_args=default_args)
    else:
        dag = DAG(
            dag_name + '_bq_raw',
            description=description,
            schedule_interval=schedule_interval,
            start_date=start_date,
            catchup=catchup,
            max_active_runs=max_active_dags,
            default_args=default_args)

    # Iterate through the sub-items on a DAG and create tasks
    for task_name in dag_yaml["tasks"]:
        task_factory(dag, dag_yaml["tasks"][task_name])
    return dag


# Load yaml file
if 'AIRFLOW_HOME' not in os.environ:
    AIRFLOW_HOME = expand_env_var('~/airflow')
else:
    AIRFLOW_HOME = expand_env_var(os.environ['AIRFLOW_HOME'])

AIRFLOW_DAGS_FOLDER = AIRFLOW_HOME + '/dags'

# Read configuration file for DAGs
DIRECTORY = AIRFLOW_DAGS_FOLDER + '/sources'
yaml_string = ''
# loop through all files in the sources dir
for filename in os.listdir(AIRFLOW_DAGS_FOLDER + '/sources'):
    if "historical" not in filename:
        with open(DIRECTORY + '/' + filename, "r") as infile:
            # append them to the dags file object
            yaml_string += infile.read()
ingestion_dags = yaml.load(yaml_string)

# Iterate through the first level and create DAGs
for dag_name in ingestion_dags:
    dag = map_to_dag(dag_name, ingestion_dags[dag_name])
    globals()[dag_name] = dag
