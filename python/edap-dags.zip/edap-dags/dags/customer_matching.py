from airflow import DAG

from UDF import utils
from twm_plugin import (
    BigQueryOperator,
    BigQueryCreateEmptyTableOperator)
from twm_plugin.operators.dataflow_operator import TWM_DataFlowPythonOperator
from twm_plugin.sensors.bigquery_job_sensor import BigQueryJobSensor
from twm_plugin.sensors.dataflow_sensor import DataflowJobSensor
from airflow.operators.sensors import ExternalTaskSensor
from datetime import timedelta, datetime
import yaml

PROJECT = utils.project()
dest_bucket = utils.gcs_transform_bucket()

yaml_file = yaml.load(open('/airflow/dags/configs/customer_matching.yaml'))
configs = yaml_file[PROJECT]
cust_params = configs['customer_matching']
cust_params['job_run_date'] = "{{ ds }}"
cust_params['job_id_airflow'] = "{{ ti.dag_id + '.' + ti.task_id + '.' }}{{ ti.job_id }}"
ds_params = configs['datastore']
ds_params['job_run_date'] = "{{ ds }}"
ds_params['job_id_airflow'] = "{{ ti.dag_id + '.' + ti.task_id + '.' }}{{ ti.job_id }}"
sources = yaml_file['sources']

REGION = yaml_file['REGION']
GCP_CONN_ID = yaml_file['GCP_CONN_ID']
CUST_MATCHING_PY_FILE = yaml_file['CUST_MATCHING_PY_FILE']
DATASTORE_PY_FILE = yaml_file['DATASTORE_PY_FILE']
BQ_TRANSFORMED = yaml_file['BQ_TRANSFORMED']
STAGING_LOCATION = configs['STAGING_LOCATION']
TEMP_LOCATION = configs['TEMP_LOCATION']

default_args = {
    'owner': 'edap',
    'project': PROJECT,
    'depends_on_past': False,
    'email': utils.getEmailList(),
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 100,
    'retry_delay': timedelta(minutes=10),
    'start_date': datetime(2018, 10, 8),
    'dataflow_default_options': {
        'project': PROJECT,
        'staging_location': STAGING_LOCATION,
        'temp_location': TEMP_LOCATION
    }
}

destination_table_prefix = PROJECT + "." + BQ_TRANSFORMED + "."

dag = DAG('customer_matching_dataflow',
          default_args=default_args,
          schedule_interval='0 7 * * *')

customer_matching = TWM_DataFlowPythonOperator(
    task_id='customer_matching_job',
    parameters=cust_params,
    py_file=CUST_MATCHING_PY_FILE,
    py_options=None,
    dataflow_default_options=None,
    options=None,
    gcp_conn_id=GCP_CONN_ID,
    delegate_to=None,
    wait_for_downstream=True,
    dag=dag
)

customer_matching_sensor = DataflowJobSensor(
    task_id='customer_matching_job_sensor',
    job_name='customer-matching-job-{{ ds }}',
    project=PROJECT,
    location=REGION,
    gcp_conn_id=GCP_CONN_ID,
    poke_interval=300,
    dag=dag
)

datastore = TWM_DataFlowPythonOperator(
    task_id='datastore_job',
    parameters=ds_params,
    py_file=DATASTORE_PY_FILE,
    py_options=None,
    dataflow_default_options=None,
    options=None,
    gcp_conn_id=GCP_CONN_ID,
    delegate_to=None,
    dag=dag
)

datastore_sensor = DataflowJobSensor(
    task_id='datastore_job_sensor',
    job_name='datastore-job-{{ ds }}',
    project=PROJECT,
    location=REGION,
    gcp_conn_id=GCP_CONN_ID,
    poke_interval=300,
    dag=dag
)

table_name = 'DIM_ENTITIES'
schema_location = ('gs://%s/transformation_views/%s.sql' %
                   (dest_bucket, table_name))
bq_create_DIM_ENTITIES = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id='transformation',
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)

bq_clear_partition_DIM_ENTITIES = BigQueryOperator(
    task_id='bq_clear_partition_' + table_name,
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    wait_for_downstream=True,
    bql='''
            DELETE
            FROM `''' + destination_table_prefix + table_name + '''`
            WHERE
                JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
    dag=dag
)

bq_write_DIM_ENTITIES = BigQueryOperator(
    task_id=('bq_write_%s' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=(
        'gs://%s/transformation_views/%s.sql' % (dest_bucket, table_name)
    ),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    dag=dag
)

wait_for_bq_write_DIM_ENTITIES = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=(
        '{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name
    ),
    dag=dag
)

table_name = 'ENTITY_INDIV_MAPPING'
schema_location = ('gs://%s/transformation_views/%s.sql' %
                   (dest_bucket, table_name))
bq_create_ENTITY_INDIV_MAPPING = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id='transformation',
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)

bq_clear_partition_ENTITY_INDIV_MAPPING = BigQueryOperator(
    task_id='bq_clear_partition_' + table_name,
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    wait_for_downstream=True,
    bql='''
            DELETE
            FROM `''' + destination_table_prefix + table_name + '''`
            WHERE
                JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
    dag=dag
)

bq_write_ENTITY_INDIV_MAPPING = BigQueryOperator(
    task_id=('bq_write_%s' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=(
        'gs://%s/transformation_views/%s.sql' % (dest_bucket, table_name)
    ),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    dag=dag
)

wait_for_bq_write_ENTITY_INDIV_MAPPING = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=(
        '{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name
    ),
    dag=dag
)

table_name = 'DIM_INDIVIDUALS'
schema_location = ('gs://%s/transformation_views/%s.sql' %
                   (dest_bucket, table_name))
bq_create_DIM_INDIVIDUALS = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id='transformation',
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)

bq_clear_partition_DIM_INDIVIDUALS = BigQueryOperator(
    task_id='bq_clear_partition_' + table_name,
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    wait_for_downstream=True,
    bql='''
            DELETE
            FROM `''' + destination_table_prefix + table_name + '''`
            WHERE
                JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
    dag=dag
)

bq_write_DIM_INDIVIDUALS = BigQueryOperator(
    task_id=('bq_write_%s' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=(
        'gs://%s/transformation_views/%s.sql' % (dest_bucket, table_name)
    ),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    dag=dag
)

wait_for_bq_write_DIM_INDIVIDUALS = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=(
        '{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name
    ),
    dag=dag
)

table_name = 'DIM_HOUSEHOLD'
schema_location = ('gs://%s/transformation_views/%s.sql' %
                   (dest_bucket, table_name))
bq_create_DIM_HOUSEHOLD = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id='transformation',
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)

bq_clear_partition_DIM_HOUSEHOLD = BigQueryOperator(
    task_id='bq_clear_partition_' + table_name,
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    wait_for_downstream=True,
    bql='''
            DELETE
            FROM `''' + destination_table_prefix + table_name + '''`
            WHERE
                JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
    dag=dag
)

bq_write_DIM_HOUSEHOLD = BigQueryOperator(
    task_id=('bq_write_%s' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=(
        'gs://%s/transformation_views/%s.sql' % (dest_bucket, table_name)
    ),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    dag=dag
)

wait_for_bq_write_DIM_HOUSEHOLD = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=(
        '{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name
    ),
    dag=dag
)

# if False:
if cust_params["full_load"] != "True":
    for source, tables in sources.items():
        for table_name, table_configs in tables.items():
            wait_for_bq_load = ExternalTaskSensor(
                task_id='wait_for_staging_bq_' + table_name,
                external_dag_id=table_configs.get('dag_id'),
                external_task_id=table_configs.get('task_id'),
                allowed_states=['success'],
                execution_delta=None,
                dag=dag)
            wait_for_bq_load >> customer_matching

customer_matching >> customer_matching_sensor >> datastore >> datastore_sensor

customer_matching_sensor >> bq_create_DIM_ENTITIES >> bq_clear_partition_DIM_ENTITIES >> \
    bq_write_DIM_ENTITIES >> wait_for_bq_write_DIM_ENTITIES

customer_matching_sensor >> bq_create_ENTITY_INDIV_MAPPING >> bq_clear_partition_ENTITY_INDIV_MAPPING >> \
    bq_write_ENTITY_INDIV_MAPPING >> wait_for_bq_write_ENTITY_INDIV_MAPPING

customer_matching_sensor >> bq_create_DIM_INDIVIDUALS >> bq_clear_partition_DIM_INDIVIDUALS >> \
    bq_write_DIM_INDIVIDUALS >> wait_for_bq_write_DIM_INDIVIDUALS >> \
    bq_create_DIM_HOUSEHOLD >> bq_clear_partition_DIM_HOUSEHOLD >> bq_write_DIM_HOUSEHOLD >> \
    wait_for_bq_write_DIM_HOUSEHOLD
