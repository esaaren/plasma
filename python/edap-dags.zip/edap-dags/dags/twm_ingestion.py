import os
from airflow import DAG
import yaml
from twm_plugin import (
    TWM_MsSqlToGoogleCloudStorageOperator,
    TWM_MySqlToGoogleCloudStorageOperator
    )
from UDF import utils
from datetime import timedelta
from airflow.configuration import expand_env_var
from twm_plugin.sensors.twm_file_sensor import FileSensor
from airflow.operators.dummy_operator import DummyOperator
from airflow.contrib.operators.file_to_gcs import FileToGoogleCloudStorageOperator
from twm_plugin.operators.gcs_to_gcs import GoogleCloudStorageToGoogleCloudStorageOperator
from airflow.contrib.operators.sftp_operator import SFTPOperator, SFTPOperation
from twm_plugin.operators.zip_operator_plugin import UnzipOperator
from twm_plugin.operators.twm_bash_operator import BashOperator
from twm_plugin.operators.twm_mssql_operator import TWM_MsSqlOperator
from twm_plugin.operators.sfmc_ingestion_transform_operator import SfmcTranformPythonOperator
from tempfile import gettempdir


def task_factory(dag, task_name, task_yaml, szone_acls, pool, pre_execution_task):
    """
        Create TWM custom Airflow tasks from yaml configuration
    """
    # Options that apply for all tasks
    source_type = task_yaml['source_type']
    source_conn = task_yaml['source_conn']

    dest_type = task_yaml['dest_type']
    dest_conn = task_yaml['dest_conn']

    # Environment Setup
    dest_bucket = utils.gcs_bucket()

    # Options specific for this operator
    sql = task_yaml['source_query']
    dest_area = task_yaml['dest_area']
    dest_szone = task_yaml['dest_szone']
    dest_sourcesys = task_yaml['dest_sourcesys']
    dest_dataset = task_yaml['dest_dataset']
    dest_export_format = task_yaml['dest_export_format']

    # Compose output file name based on configuration
    filename = utils.datalake_filename(
        dest_area,
        dest_szone,
        dest_sourcesys,
        dest_dataset,
        dest_export_format)

    # Compose schema file name based on configuration
    schema = utils.datalake_schema(
        dest_area,
        dest_szone,
        dest_sourcesys,
        dest_dataset,
        dest_export_format)

    acls = szone_acls[dest_szone]

    metadata = utils.datalake_metadata(
        dest_area,
        dest_szone,
        dest_sourcesys,
        dest_dataset,
        dest_export_format)

    # CSV file format options
    dest_csv_columnheader = str(task_yaml.get(
        'dest_csv_columnheader', 'False'))
    # Microsoft SQL Server to Google Cloud Storage
    if source_type == "mssql" and dest_type == "gcs":
        # Create task
        get_raw = TWM_MsSqlToGoogleCloudStorageOperator(
            task_id=task_name,
            mssql_conn_id=source_conn,
            sql=sql,
            google_cloud_storage_conn_id=dest_conn,
            bucket=dest_bucket,
            filename=filename,
            schema_filename=schema,
            acls=acls,
            pool=pool,
            metadata_filename=metadata,
            csv_delimiter='|',
            export_format={
                'file_format': dest_export_format,
                'csv_columnheader': dest_csv_columnheader,
            },
            dag=dag
        )
        if pre_execution_task != 'False':
            get_raw.set_upstream(pre_execution_task)

    # MySQL to Google  Cloud Storage
    elif source_type == "mysql" and dest_type == "gcs":
        TWM_MySqlToGoogleCloudStorageOperator(
            task_id=task_name,
            mysql_conn_id=source_conn,
            sql=sql,
            google_cloud_storage_conn_id=dest_conn,
            bucket=dest_bucket,
            filename=filename,
            schema_filename=schema,
            acls=acls,
            pool=pool,
            metadata_filename=metadata,
            csv_delimiter='|',
            export_format={
                'file_format': dest_export_format,
                'csv_columnheader': dest_csv_columnheader,
            },
            dag=dag
        )
        # Redundant code look to refactor
        if pre_execution_task != 'False':
            get_raw.set_upstream(pre_execution_task)
    elif source_type == "sfmc" and dest_type == "gcs":
        local_path = "/airflow/temp/"
        datetime_str = "{{ ds_nodash }}"
        local_file = dest_dataset + datetime_str + ".csv"
        local_file_backup_path = local_path + dest_dataset + datetime_str + "_bak.csv"
        local_file_path = local_path + local_file
        remote_file = task_yaml['source_path']

        download = SFTPOperator(
            task_id='download_from_sftp_' + dest_dataset,
            ssh_conn_id=source_conn,
            pool=pool,
            local_filepath=local_file_path,
            remote_filepath=remote_file,
            operation=SFTPOperation.GET,
            dag=dag)

        # we want to upload the transformed file with the original name, so rename this one
        mv_cmd = "mv " + local_file_path + " " + local_file_backup_path
        rename_file = BashOperator(
            task_id='rename_' + dest_dataset,
            pool=pool,
            bash_command=mv_cmd,
            dag=dag)

        columns_to_ignore = task_yaml.get('columns_to_ignore', None)
        transform_sfmc_csv = SfmcTranformPythonOperator(
            task_id='transform_sf_csv_' + dest_dataset,
            path_to_csv=local_file_backup_path,
            path_to_write_csv=local_file_path,
            columns_to_ignore=columns_to_ignore,
            current_encoding=task_yaml.get("encoding", "utf-16"),
            datetime="{{ ds }}",
            dag=dag)

        upload_to_gcs = FileToGoogleCloudStorageOperator(
            task_id='upload_file_to_gcs_' + dest_dataset,
            src=local_file_path,
            pool=pool,
            dst=filename,
            bucket=dest_bucket,
            google_cloud_storage_conn_id=dest_conn,
            dag=dag)

        delete_local_file = BashOperator(
            task_id='delete_local_' + dest_dataset,
            pool=pool,
            bash_command='rm ' + local_file_path,
            dag=dag)

        delete_utf8_file = BashOperator(
            task_id='delete_original_' + dest_dataset,
            pool=pool,
            bash_command='rm ' + local_file_backup_path,
            dag=dag)

        sfmc_schema = "schema/" + dest_dataset + "_bqschema"
        upload_schema = GoogleCloudStorageToGoogleCloudStorageOperator(
            task_id='upload_schema_' + dest_dataset,
            google_cloud_storage_conn_id=dest_conn,
            source_bucket="edap-prod-sfmc",
            source_object=sfmc_schema,
            destination_bucket=dest_bucket,
            destination_object=schema,
            move_object=False,
            dag=dag)

        # BQ Raw ingestion dags look for a task with this name to complete
        signal_done = DummyOperator(
            task_id=task_name,
            dag=dag
        )

        rename_file.set_upstream(download)
        transform_sfmc_csv.set_upstream(rename_file)
        upload_to_gcs.set_upstream(transform_sfmc_csv)
        upload_schema.set_upstream(upload_to_gcs)
        delete_local_file.set_upstream(upload_to_gcs)
        delete_utf8_file.set_upstream(upload_to_gcs)
        signal_done.set_upstream(upload_schema)
        signal_done.set_upstream(delete_local_file)
        signal_done.set_upstream(delete_utf8_file)

    elif source_type == "sfmc-zip" and dest_type == "gcs":
        datetime_str = "{{ ds_nodash }}"
        local_folder = "/airflow/temp/" + datetime_str + "/"
        initial_zip = task_yaml.get('initial_zip', False)
        local_file = dest_dataset + ".csv"
        local_file_path = local_folder + local_file
        local_file_backup_path = local_folder + dest_dataset + "_bak.csv"

        wait_for_file = FileSensor(
            task_id='wait_for_' + dest_dataset,
            filepath=local_file_path,
            fs_conn_id='file_system',
            pool='ingestion_wait',
            dag=dag)

        mv_cmd = "mv " + local_file_path + " " + local_file_backup_path
        rename_file = BashOperator(
            task_id='rename_' + dest_dataset,
            pool=pool,
            bash_command=mv_cmd,
            dag=dag)

        columns_to_ignore = task_yaml.get('columns_to_ignore', None)
        transform_sfmc_csv = SfmcTranformPythonOperator(
            task_id='transform_sf_csv_' + dest_dataset,
            path_to_csv=local_file_backup_path,
            path_to_write_csv=local_file_path,
            columns_to_ignore=columns_to_ignore,
            current_encoding=task_yaml.get("encoding", "utf-8"),
            datetime="{{ ds }}",
            dag=dag)

        upload_to_gcs = FileToGoogleCloudStorageOperator(
            task_id='upload_to_gcs_' + dest_dataset,
            pool=pool,
            src=local_file_path,
            dst=filename,
            bucket=dest_bucket,
            google_cloud_storage_conn_id=dest_conn,
            dag=dag)

        delete_local = BashOperator(
            task_id='delete_local_' + dest_dataset,
            pool=pool,
            bash_command='rm ' + local_file_path,
            dag=dag)

        delete_original = BashOperator(
            task_id='delete_original_' + dest_dataset,
            pool=pool,
            bash_command='rm ' + local_file_backup_path,
            dag=dag)

        sfmc_schema = "schema/" + dest_dataset + "_bqschema"
        upload_schema = GoogleCloudStorageToGoogleCloudStorageOperator(
            task_id='upload_schema_' + dest_dataset,
            google_cloud_storage_conn_id=dest_conn,
            source_bucket="edap-prod-sfmc",
            source_object=sfmc_schema,
            destination_bucket=dest_bucket,
            destination_object=schema,
            move_object=False,
            dag=dag)

        # BQ Raw ingestion dags look for a task with this name to complete
        signal_done = DummyOperator(
            task_id=task_name,
            dag=dag
        )

        rename_file.set_upstream(wait_for_file)
        transform_sfmc_csv.set_upstream(rename_file)
        upload_to_gcs.set_upstream(transform_sfmc_csv)
        upload_schema.set_upstream(upload_to_gcs)
        delete_local.set_upstream(upload_to_gcs)
        delete_original.set_upstream(upload_to_gcs)
        signal_done.set_upstream(upload_schema)
        signal_done.set_upstream(delete_local)
        signal_done.set_upstream(delete_original)
        # This gives the ability to download an initial dump from Salesforce
        # won't be used often but is there if needed
        # initial dump files are one big zip that contain a larger time period of data.
        if initial_zip:
            datetime_str = "{{ ds_nodash }}"
            local_zip_file = "DailyTrackingExtract" + datetime_str + ".zip"
            local_zip_path = local_folder + local_zip_file
            remote_zip_file = "/export/EDAP/DailyDeltaFiles/DailyTrackingExtract_{{ ds_nodash }}.zip"

            mkdir = BashOperator(
                task_id='make_unzip_directory',
                pool=pool,
                bash_command='mkdir -p ' + local_folder,  # create directory if it does not exist
                dag=dag)

            download_zip = SFTPOperator(
                task_id='download_salesforce_zip_file_from_sftp',
                pool=pool,
                ssh_conn_id=source_conn,
                local_filepath=local_zip_path,
                remote_filepath=remote_zip_file,
                operation=SFTPOperation.GET,
                dag=dag)

            unzip = UnzipOperator(
                task_id='unzip',
                pool=pool,
                path_to_zip_file=local_zip_path,
                path_to_unzip_contents=local_folder,
                dag=dag)

            delete_zip = BashOperator(
                task_id='delete_local_zipped_file',
                pool=pool,
                bash_command='rm ' + local_zip_path,
                dag=dag)

            download_zip.set_upstream(mkdir)
            unzip.set_upstream(download_zip)
            delete_zip.set_upstream(unzip)
            wait_for_file.set_upstream(delete_zip)


def map_to_dag(dag_name, dag_yaml, szone_acls):
    """
        Create an Airflow DAG object from yaml configuration file
    """
    description = dag_yaml.get('description', "")
    schedule_interval = dag_yaml.get('schedule_interval', "")
    start_date = dag_yaml.get('start_date', "")
    end_date = dag_yaml.get('end_date', "")
    catchup = dag_yaml.get('catchup', False)
    max_active_dags = dag_yaml.get('max_active_dags', 16)
    connection_pool = dag_yaml.get('pool', "Main")

    default_args = {
        'owner': 'edap',
        'depends_on_past': False,
        'email': utils.getEmailList(),
        'email_on_failure': True,
        'email_on_retry': True,
        'retries': 2,
        'retry_delay': timedelta(minutes=3),
    }
    # Check for end date if there is one it is a backfill DAG.
    if end_date != "":
        dag = DAG(
            dag_name + '_gcs',
            description=description,
            schedule_interval=schedule_interval,
            start_date=start_date,
            end_date=end_date,
            catchup=catchup,
            max_active_runs=max_active_dags,
            default_args=default_args)
    else:
        dag = DAG(
            dag_name + '_gcs',
            description=description,
            schedule_interval=schedule_interval,
            start_date=start_date,
            catchup=catchup,
            max_active_runs=max_active_dags,
            default_args=default_args)

    # Check if there is a pre-execution task if there is
    pre_execution_task = dag_yaml.get('pre_execution', 'False')

    if pre_execution_task != 'False':
        pre_execution_task = TWM_MsSqlOperator(
            task_id='pre-execution-task',
            pool=connection_pool,
            mssql_conn_id=dag_yaml['pre_execution']['source_conn'],
            sql=dag_yaml['pre_execution']['source_query']
        )
    # Iterate through the sub-items on a DAG and create tasks
    for task_name in dag_yaml["tasks"]:
        task_factory(dag,
                     task_name,
                     dag_yaml["tasks"][task_name],
                     szone_acls,
                     connection_pool,
                     pre_execution_task)
    return dag


# Load yaml file
if 'AIRFLOW_HOME' not in os.environ:
    AIRFLOW_HOME = expand_env_var('~/airflow')
else:
    AIRFLOW_HOME = expand_env_var(os.environ['AIRFLOW_HOME'])

AIRFLOW_DAGS_FOLDER = AIRFLOW_HOME + '/dags'

# Read configuration file for ACLs
szones_config_file = open(AIRFLOW_DAGS_FOLDER + '/twm_ingestion_szones.yaml')
szone_acls = utils.read_config(szones_config_file)

# Read configuration file for DAGs
DIRECTORY = AIRFLOW_DAGS_FOLDER + '/sources'
yaml_string = ''
# loop through all files in the sources dir
for filename in os.listdir(AIRFLOW_DAGS_FOLDER + '/sources'):
    with open(DIRECTORY + '/' + filename, "r") as infile:
        # append them to the dags file object
        yaml_string += infile.read()
ingestion_dags = yaml.load(yaml_string)

# Iterate through the first level and create DAGs
for dag_name in ingestion_dags:
    dag = map_to_dag(dag_name, ingestion_dags[dag_name], szone_acls)
    globals()[dag_name] = dag
