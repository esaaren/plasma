bq show --format=prettyjson twm-edap-prod-1802:raw.sip_apex_store > schema.json

bq mk --time_partitioning_field  partition_date --table  twm-edap-prod-1802:raw.sip_apex_store_chris_inc schema.json

--- run in BQ with "destination Table"
  SELECT CAST('2018-07-02' AS DATE) as partition_date, t.* from `twm-edap-prod-1802.raw.sip_apex_store` t
  WHERE FORMAT_DATE("%Y-%m-%d", CAST(CAST(t.last_modify_date as timestamp) as date)) = '2006-11-16'
  LIMIT 100

bq show --format=prettyjson twm-edap-dev-1802:staging.hyb_addresses_copy > schema.json

bq mk --time_partitioning_field  new_partition_column --table  twm-edap-dev-1802:staging.staging_dag_test schema.json

--- ran in BQ using Destination table
--- in prod we will use INSERT statement
--- assume table was ingested and contains data for 2018-07-01
--- then query from the day before to fill in gaps
select CAST('2018-07-02' AS DATE) as partition_date, t.* from `twm-edap-prod-1802.raw.sip_apex_store_chris_inc_master` t
    where partition_date = CAST('2018-07-01' AS DATE)
    AND t.store_key NOT IN (SELECT store_key from `twm-edap-prod-1802.raw.sip_apex_store_chris_inc` t where partition_date = CAST('2018-07-02' AS DATE) )





--For catchup tables
--Get new data from incremental ingestion
---INSERT INTO raw_master will preface this
SELECT CAST('2018-07-02' AS DATE) AS new_partition_column, t.* from raw_ingested_incremental t
    WHERE existing_partition_column = CAST('2018-07-02' AS DATE))
---Additionally the above would include any additional column updates such as "latest" flag

--Fill in data from the previous partition
---INSERT INTO raw_master will preface this
SELECT CAST('2018-07-02' AS DATE) AS new_partition_column, t.* FROM raw_master t
    WHERE existing_partition_column = CAST('2018-07-01' AS DATE)
    AND t.some_key NOT IN (SELECT some_key from raw_ingested_incremental t WHERE existing_partition_column = CAST('2018-07-02' AS DATE))
---Additionally the above would include any additional column updates such as "latest" flag






