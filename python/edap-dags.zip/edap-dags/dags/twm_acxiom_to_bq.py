from datetime import timedelta, datetime

from airflow import DAG
from airflow.contrib.operators.gcs_download_operator import GoogleCloudStorageDownloadOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.sensors import ExternalTaskSensor
from twm_plugin.sensors.bigquery_job_sensor import BigQueryJobSensor

from UDF import utils
from twm_plugin import (
    BigQueryOperator,
    BigQueryCreateEmptyTableOperator, TWM_GoogleCloudStorageToBigQueryOperator)

schedule_interval = '0 7 * * *'
start_date = datetime(2018, 10, 3)
max_active_dags = 1

default_args = {
    'owner': 'edap',
    'depends_on_past': False,
    'email': utils.getEmailList(),
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 2,
    'retry_delay': timedelta(minutes=3),
}

dag = DAG(
    'acxiom_to_bq',
    schedule_interval=schedule_interval,
    start_date=start_date,
    max_active_runs=max_active_dags,
    catchup=True,
    default_args=default_args)

PROJECT = utils.project()
dest_bucket = utils.gcs_dataflow_bucket()

raw_destination_table_prefix = PROJECT + ".raw."
staging_destination_table_prefix = PROJECT + ".staging."

acxiom_files = {
    "acxiom_cdi_responses": "acxiom_to_tw_daily_output_01_{{ ds_nodash }}.csv",
    "acxiom_ibe_responses": "acxiom_to_tw_ibe_output_01_{{ ds_nodash }}.csv",
    "acxiom_cdi_refresh_responses": "acxiom_to_tw_refresh_output_01_{{ ds_nodash }}.csv"
}

acxiom_task_name = {
    "acxiom_cdi_responses": "upload_extract_file_to_gcs_daily",
    "acxiom_ibe_responses": "upload_extract_file_to_gcs_ibe",
    "acxiom_cdi_refresh_responses": "upload_extract_file_to_gcs_refresh"
}

acxiom_primary_keys = {
    "acxiom_cdi_responses": ['SOURCE_EKEY'],
    "acxiom_ibe_responses": ['FULL_NAME', 'POSTAL_CD_5', 'POSTAL_CD_4', 'CONS_LNK', 'ADDR_LNK'],
    "acxiom_cdi_refresh_responses": ['SOURCE_EKEY']
}

dag_complete = DummyOperator(task_id='dag_complete', dag=dag)

for table_name, file_name in acxiom_files.items():
    # Specify and reinit variables for ingestion of acxiom_CDI_RESPONSES
    source_prefix = 'raw/red/acxiom_enrichment/in/{{ ds_nodash }}/'
    source_path = source_prefix + file_name
    schema = table_name + '.json'
    schema_path = 'acxiom_schemas/' + schema
    full_schema_path = 'gs://' + dest_bucket + '/' + schema_path

    primary_keys_string = ''
    for _, key in enumerate(acxiom_primary_keys.get(table_name)):
        primary_keys_string += ''' AND t.''' + key + ''' = s.''' + key

    if utils.isDevelopmentEnvironment():
        # if dev environment, use a DummyOperator because ingestion doesn't happen on dev instance
        dummy_wait = DummyOperator(task_id='fake_wait_for_enrichment',
                                   dag=dag)  # This is run instead of wait task on dev env
    else:
        wait_for_acxiom_in = ExternalTaskSensor(
            task_id='wait_for_acxiom_in',
            external_dag_id='acxiom_enrichment_in',
            external_task_id=acxiom_task_name.get(table_name),  # Get the name of the external task from the map
            execution_delta=None,  # Same day as today
            poke_interval=60,
            dag=dag
        )

    bq_create_empty_table_raw = BigQueryCreateEmptyTableOperator(
        task_id='bq_create_empty_table_raw_' + table_name,
        project_id=PROJECT,
        dataset_id='raw',
        table_id=table_name,
        gcs_schema_object=full_schema_path,
        google_cloud_storage_conn_id='gcs',
        bigquery_conn_id='gbq',
        time_partitioning={'field': 'JOB_RUN_DATE'},
        dag=dag
    )
    bq_clear_partition_raw = BigQueryOperator(
        task_id='bq_clear_partition_raw_' + table_name,
        bigquery_conn_id='gbq',
        use_legacy_sql=False,
        write_disposition='WRITE_APPEND',
        allow_large_results=True,
        wait_for_downstream=True,
        sql='''
            DELETE
            FROM `''' + raw_destination_table_prefix + table_name + '''`
            WHERE
                JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
        dag=dag
    )
    bq_raw_load = TWM_GoogleCloudStorageToBigQueryOperator(
        task_id='bq_raw_load_' + table_name,
        bucket=dest_bucket,
        source_objects=[source_path],
        destination_project_dataset_table=raw_destination_table_prefix + table_name,
        source_format='CSV',
        create_disposition='CREATE_IF_NEEDED',
        schema_object=schema_path,
        field_delimiter='|',
        quote_character='"',
        ignore_unknown_values=False,
        allow_quoted_newlines=True,
        allow_jagged_rows=False,
        bigquery_conn_id='gbq',
        google_cloud_storage_conn_id='gcs',
        write_disposition='WRITE_APPEND',
        time_partitioning={"field": 'JOB_RUN_DATE'},
        skip_leading_rows=1,
        dag=dag
    )
    gcs_download_schema = GoogleCloudStorageDownloadOperator(
        task_id='gcs_download_schema_' + table_name,
        google_cloud_storage_conn_id='gcs',
        bucket=dest_bucket,
        object=schema_path,
        store_to_xcom_key='TABLE_SCHEMA',
        dag=dag
    )
    gcs_create_staging_schema = PythonOperator(
        task_id='gcs_create_staging_schema_' + table_name,
        provide_context=True,
        python_callable=utils.create_staging_schema,
        params={"source_table": table_name},
        dag=dag
    )
    bq_create_empty_table_staging = BigQueryCreateEmptyTableOperator(
        task_id='bq_create_empty_table_staging_' + table_name,
        project_id=PROJECT,
        dataset_id='staging',
        table_id=table_name,
        schema_fields='{{ ti.xcom_pull(task_ids="gcs_create_staging_schema_' + table_name + '", key="TABLE_SCHEMA") }}',
        bigquery_conn_id='gbq',
        time_partitioning={'field': 'JOB_RUN_DATE'},
        dag=dag
    )
    bq_clear_partition_staging = BigQueryOperator(
        task_id='bq_clear_partition_staging_' + table_name,
        bigquery_conn_id='gbq',
        use_legacy_sql=False,
        write_disposition='WRITE_APPEND',
        allow_large_results=True,
        wait_for_downstream=True,
        bql='''
            DELETE
            FROM `''' + staging_destination_table_prefix + table_name + '''`
            WHERE
                JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
        dag=dag
    )
    bq_write_to_staging = BigQueryOperator(
        task_id='bq_write_to_staging_' + table_name,
        bigquery_conn_id='gbq',
        use_legacy_sql=False,
        write_disposition='WRITE_APPEND',
        allow_large_results=True,
        time_partitioning={"field": 'JOB_RUN_DATE'},
        bql='''
            SELECT
            CAST("{{ ds }}" as DATETIME) as CDC_START_DATE,
            CAST(NULL as DATETIME) as CDC_END_DATE,
            True as CURRENT_FLAG,
            "{{ ti.dag_id + '.' + ti.task_id + '.' }}{{ ti.job_id }}" as JOB_ID,
            t.*
            FROM `''' + raw_destination_table_prefix + table_name + '''` t
            WHERE
                t.JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
        destination_dataset_table=staging_destination_table_prefix + table_name,
        store_to_xcom_key='STAGING_WRITE_JOB_ID',
        check_job_status=False,
        schema_object=schema_path,
        dag=dag
    )
    wait_for_bq_write = BigQueryJobSensor(
        task_id='wait_for_bq_write_' + table_name,
        project_id=PROJECT,
        bigquery_conn_id='gbq',
        job_id='{{ ti.xcom_pull(task_ids="bq_write_to_staging_' + table_name + '", key="STAGING_WRITE_JOB_ID") }}',
    )
    bq_backfill_non_updated_records = BigQueryOperator(
        task_id='bq_backfill_non_updated_records_' + table_name,
        bigquery_conn_id='gbq',
        use_legacy_sql=False,
        write_disposition='WRITE_APPEND',
        allow_large_results=True,
        wait_for_downstream=True,
        time_partitioning={"field": 'JOB_RUN_DATE'},
        bql='''
            SELECT
            CAST("{{ ds }}" as DATE) as JOB_RUN_DATE,
            "{{ ti.dag_id + '.' + ti.task_id + '.' }}{{ ti.job_id }}" as JOB_ID,
            t.* EXCEPT (JOB_RUN_DATE, JOB_ID)
            FROM `''' + staging_destination_table_prefix + table_name + '''` t
            WHERE
                t.JOB_RUN_DATE = CAST("{{ yesterday_ds }}" as DATE)
                AND NOT EXISTS
                (SELECT * FROM `''' + staging_destination_table_prefix + table_name + '''` s
                    WHERE s.JOB_RUN_DATE = CAST("{{ ds }}" as DATE) ''' + primary_keys_string +
            ''' AND s.CDC_START_DATE = t.CDC_START_DATE''' +
            ''' ) ''',
        destination_dataset_table=staging_destination_table_prefix + table_name,
        store_to_xcom_key='STAGING_BACKFILL_NON_UPDATED_JOB_ID',
        check_job_status=False,
        dag=dag
    )
    wait_for_bq_non_updated_backfill = BigQueryJobSensor(
        task_id='wait_for_bq_non_updated_backfill_' + table_name,
        project_id=PROJECT,
        bigquery_conn_id='gbq',
        job_id='{{ ti.xcom_pull(task_ids="bq_backfill_non_updated_records_' + table_name +
               '", key="STAGING_BACKFILL_NON_UPDATED_JOB_ID") }}',
    )

    if utils.isDevelopmentEnvironment():
        # if dev environment, use a DummyOperator because ingestion doesn't happen on dev instance
        bq_create_empty_table_raw.set_upstream(dummy_wait)
    else:
        # Wait for the enriched acxiom file to complete
        bq_create_empty_table_raw.set_upstream(wait_for_acxiom_in)
    # Clear partition and load into it from CSV in GCS
    bq_clear_partition_raw.set_upstream(bq_create_empty_table_raw)
    bq_raw_load.set_upstream(bq_clear_partition_raw)
    # Grab schema and modify it to add staging columns
    gcs_download_schema.set_upstream(bq_raw_load)
    gcs_create_staging_schema.set_upstream(gcs_download_schema)
    # Always make sure the BQ create staging table task depends on the create staging schema task
    bq_create_empty_table_staging.set_upstream(gcs_create_staging_schema)
    # CLear the partition we are about to insert data into, in case of previously failed task
    bq_clear_partition_staging.set_upstream(bq_create_empty_table_staging)
    # Always make sure the BQ staging write task depends on the gcs_create_staging_schema`
    bq_write_to_staging.set_upstream(bq_clear_partition_staging)
    # Wait for the BQ job to finish
    wait_for_bq_write.set_upstream(bq_write_to_staging)
    bq_backfill_non_updated_records.set_upstream(wait_for_bq_write)
    wait_for_bq_non_updated_backfill.set_upstream(bq_backfill_non_updated_records)
    dag_complete.set_upstream(wait_for_bq_non_updated_backfill)
