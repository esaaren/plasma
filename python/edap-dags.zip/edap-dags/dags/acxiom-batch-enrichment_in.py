import yaml
from datetime import timedelta, datetime
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.contrib.operators.file_to_gcs import FileToGoogleCloudStorageOperator
from airflow.contrib.operators.sftp_operator import SFTPOperator, SFTPOperation
from airflow.operators.python_operator import PythonOperator
from twm_plugin.operators.pgp_operator import TWM_PGPDecryptOperator
from twm_plugin.sensors.gcs_sensor import GoogleCloudStorageObjectSensor
from twm_plugin.sensors.sftp_sensor import SFTPSensor
import os
import csv
import pandas as pd
import logging
from airflow.configuration import expand_env_var
from UDF import utils


def add_job_run_date(templates_dict, *args, **kwargs):
    """Execute the job."""
    input_file = templates_dict['input_file']
    output_file = templates_dict['output_file']
    delimiter = templates_dict['delimiter']
    csv_input = pd.read_csv(input_file, sep=delimiter)
    csv_input['JOB_RUN_DATE'] = str(kwargs['ds'])
    csv_input.to_csv(output_file, sep=delimiter, index=False)


def add_job_run_date2(templates_dict, *args, **kwargs):
    input_file = templates_dict['input_file']
    output_file = templates_dict['output_file']
    delimiter = templates_dict['delimiter']
    with open(input_file, 'r') as csvinput:
        with open(output_file, 'w') as csvoutput:
            writer = csv.writer(
                csvoutput, lineterminator='\n', delimiter=delimiter)
            reader = csv.reader(csvinput, delimiter=delimiter)
            all = []
            row = next(reader)
            row.append('JOB_RUN_DATE')
            all.append(row)
            for row in reader:
                row.append(str(kwargs['ds']))
                all.append(row)
            writer.writerows(all)


if 'passphrase' not in os.environ:
    passphrase = expand_env_var('test')
else:
    passphrase = expand_env_var(os.environ['passphrase'])


default_args = {
    'owner': 'edap',
    'depends_on_past': False,
    'email': utils.getEmailList(),
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 1,
    'retry_delay': timedelta(minutes=10),
    'start_date': datetime(2018, 10, 3)
}

dag = DAG('acxiom_enrichment_in',
          default_args=default_args,
          schedule_interval='@once')

configs = yaml.load(
    open('/airflow/dags/configs/acxiom_batch_enrichment_in.yaml'))
PROJECT = utils.project()
bucket = utils.gcs_bucket()
GCP_CONN_ID = configs['GCP_CONN_ID']
SFTP_CONN_ID = configs['SFTP_CONN_ID']
services = configs['services']
local_file_path = configs['local_file_path']
remote_file_path = configs['remote_file_path']

for service in services:
    config = services[service]
    gcs_file_path = config['gcs_file_path']
    encrypted_file_name = config['encrypted_file_name']
    unencrypted_file_name = config['unencrypted_file_name']
    control_file_name = config['control_file_name']
    temp_file_name = config['temp_file_name']

    wait = SFTPSensor(
        task_id='acxiom_result_file_sensor_' + service,
        path=remote_file_path + control_file_name,
        sftp_conn_id=SFTP_CONN_ID,
        poke_interval=30,
        dag=dag)

    download_extract = SFTPOperator(
        task_id='download_acxiom_extract_from_sftp_' + service,
        ssh_conn_id=SFTP_CONN_ID,
        local_filepath=local_file_path + encrypted_file_name,
        remote_filepath=remote_file_path + encrypted_file_name,
        operation=SFTPOperation.GET,
        dag=dag)

    download_control_card = SFTPOperator(
        task_id='download_control_card_from_sftp_' + service,
        ssh_conn_id=SFTP_CONN_ID,
        local_filepath=local_file_path + control_file_name,
        remote_filepath=remote_file_path + control_file_name,
        operation=SFTPOperation.GET,
        dag=dag)

    decrypt = TWM_PGPDecryptOperator(
        task_id='decrypt_downloaded_file_' + service,
        src_encrypted_file_location=local_file_path + encrypted_file_name,
        dest_decrypted_file_location=local_file_path + temp_file_name,
        passphrase=passphrase,
        dag=dag)

    if service == "daily" or service == "ibe" or service == "refresh":
        append_job_run_date = PythonOperator(
            task_id='append_job_run_date_' + service,
            python_callable=add_job_run_date2,
            templates_dict={
                'input_file': local_file_path + temp_file_name,
                'output_file': local_file_path + unencrypted_file_name,
                'delimiter': '|'},
            provide_context=True,
            dag=dag
        )

    upload_extract_to_gcs = FileToGoogleCloudStorageOperator(
        task_id='upload_extract_file_to_gcs_' + service,
        src=local_file_path + unencrypted_file_name,
        dst=gcs_file_path + unencrypted_file_name,
        bucket=bucket,
        google_cloud_storage_conn_id=GCP_CONN_ID,
        dag=dag)

    upload_control_card_to_gcs = FileToGoogleCloudStorageOperator(
        task_id='upload_control_card_to_gcs_' + service,
        src=local_file_path + control_file_name,
        dst=gcs_file_path + control_file_name,
        bucket=bucket,
        google_cloud_storage_conn_id=GCP_CONN_ID,
        dag=dag)

    delete_local = BashOperator(
        task_id='delete_local_encrypted_acxiom_extract_' + service,
        # depends_on_past=False,
        bash_command='rm ' + local_file_path + encrypted_file_name,
        dag=dag)

    delete_original = BashOperator(
        task_id='delete_local_unencrypted_acxiom_extract_' + service,
        # depends_on_past=False,
        bash_command='rm ' + local_file_path + unencrypted_file_name,
        # trigger_rule='all_done',
        dag=dag)

    if service == "daily" or service == "ibe" or service == "refresh":
        delete_temp = BashOperator(
            task_id='delete_local_temp_acxiom_extract_' + service,
            # depends_on_past=False,
            bash_command='rm ' + local_file_path + temp_file_name,
            dag=dag)

    delete_local_control_file = BashOperator(
        task_id='delete_local_control_card_' + service,
        # depends_on_past=False,
        bash_command='rm ' + local_file_path + control_file_name,
        dag=dag)

    wait >> download_control_card >> upload_control_card_to_gcs >> \
        delete_local_control_file

    if service == "daily" or service == "ibe" or service == "refresh":
        wait >> download_extract >> decrypt >> append_job_run_date >> \
            upload_extract_to_gcs >> delete_local >> delete_original >> \
            delete_temp
    else:
        wait >> download_extract >> decrypt >> upload_extract_to_gcs >> \
            delete_local >> delete_original
