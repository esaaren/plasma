from airflow import DAG
from datetime import timedelta, datetime

from UDF import utils
from twm_plugin import (
    BigQueryOperator,
    BigQueryCreateEmptyTableOperator)
from twm_plugin.sensors.bigquery_job_sensor import BigQueryJobSensor


default_args = {
    'owner': 'edap',
    'depends_on_past': False,
    'email': utils.getEmailList(),
    'email_on_failure': True,
    'email_on_retry': True,
    'retries': 2,
    'retry_delay': timedelta(minutes=3),
}

dag = DAG(
    'bq_raw_to_bq_transformed_init',
    start_date=datetime.today(),
    schedule_interval=None,
    max_active_runs=1,
    catchup=False,
    default_args=default_args)

PROJECT = utils.project()
BQ_TRANSFORMED = "transformation"
destination_table_prefix = PROJECT + "." + BQ_TRANSFORMED + "."
dest_bucket = utils.gcs_transform_bucket()


table_name = 'TXN_TO_ENTITY_MAPPING'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_TXN_TO_ENTITY_MAPPING = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_TXN_TO_ENTITY_MAPPING = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'TXN_TO_ENTITY_MAPPING_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_TXN_TO_ENTITY_MAPPING = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_TXN_TO_ENTITY_MAPPING_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'TXN_TO_ENTITY_MAPPING_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_TXN_TO_ENTITY_MAPPING_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'FACT_TXN_LINEITEMS_APEX_XCENTER'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_FACT_TXN_LINEITEMS_APEX_XCENTER = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_APEX_XCENTER_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_APEX_XCENTER_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'FACT_TXN_LINEITEMS_APEX_HYBRIS'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_FACT_TXN_LINEITEMS_APEX_HYBRIS = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_APEX_HYBRIS_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_APEX_HYBRIS_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'FACT_TXN_LINEITEMS_NON_PHYS'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_FACT_TXN_LINEITEMS_NON_PHYS = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_FACT_TXN_LINEITEMS_NON_PHYS = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_NON_PHYS_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_NON_PHYS = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_FACT_TXN_LINEITEMS_NON_PHYS_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_NON_PHYS_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_NON_PHYS_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'FACT_TXN_LINEITEMS_APEX_JOINED'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_FACT_TXN_LINEITEMS_APEX_JOINED = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_FACT_TXN_LINEITEMS_APEX_JOINED = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_APEX_JOINED_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_JOINED = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_FACT_TXN_LINEITEMS_APEX_JOINED_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_APEX_JOINED_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_JOINED_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'FACT_TXN_LINEITEMS_APEX_WISH'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_FACT_TXN_LINEITEMS_APEX_WISH = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_FACT_TXN_LINEITEMS_APEX_WISH = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_APEX_WISH_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_FACT_TXN_LINEITEMS_APEX_WISH_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_APEX_WISH_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'FACT_TXN_LINEITEMS_APEX_WISH_JOINED'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_FACT_TXN_LINEITEMS_APEX_WISH_JOINED = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_APEX_WISH_JOINED_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEMS_APEX_WISH_JOINED_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'FACT_TXN_LINEITEM'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_FACT_TXN_LINEITEM = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_FACT_TXN_LINEITEM = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEM_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEM = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_FACT_TXN_LINEITEM_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_LINEITEM_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_LINEITEM_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'FACT_TXN'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_FACT_TXN = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_FACT_TXN = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_FACT_TXN_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'FACT_TXN_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_FACT_TXN_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'DIM_DATE'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_DIM_DATE = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_DIM_DATE = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'DIM_DATE_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_DIM_DATE = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_DIM_DATE_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'DIM_DATE_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_DIM_DATE_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'DIM_STORE'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_DIM_STORE = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_DIM_STORE = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'DIM_STORE_pre_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_DIM_STORE = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)
bq_write_DIM_STORE_2 = BigQueryOperator(
    task_id=('bq_write_%s_part2' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, 'DIM_STORE_post_2015_01_01')),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_DIM_STORE_2 = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s_part2' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)

table_name = 'DIM_LOYALTY_ACCT'
schema_location = ('gs://%s/transformation_schemas/%s.json' % (dest_bucket, table_name))
bq_create_DIM_LOYALTY_ACCT = BigQueryCreateEmptyTableOperator(
    task_id='bq_create_' + table_name,
    project_id=PROJECT,
    dataset_id=BQ_TRANSFORMED,
    table_id=table_name,
    gcs_schema_object=schema_location,
    bigquery_conn_id='gbq',
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    dag=dag
)
bq_write_DIM_LOYALTY_ACCT = BigQueryOperator(
    task_id=('bq_write_%s_part1' % table_name),
    bigquery_conn_id='gbq',
    use_legacy_sql=False,
    write_disposition='WRITE_APPEND',
    allow_large_results=True,
    sql=('gs://%s/transformation_initial_load/%s.sql' % (dest_bucket, table_name)),
    destination_dataset_table=destination_table_prefix + table_name,
    store_to_xcom_key='TRANSFORMATION_SQL',
    check_job_status=False,
    google_cloud_storage_conn_id='gcp_logging_connection',
    time_partitioning={'field': 'JOB_RUN_DATE'},
    schema_object=schema_location,
    wait_for_downstream=True,
    pool='bq_long_task_pool_transformation',
    dag=dag
)
wait_for_bq_write_DIM_LOYALTY_ACCT = BigQueryJobSensor(
    task_id=('wait_for_bq_write_%s' % table_name),
    project_id=PROJECT,
    bigquery_conn_id='gbq',
    job_id=('{{ ti.xcom_pull(task_ids="bq_write_%s", key="TRANSFORMATION_SQL") }}' % table_name),
)


bq_write_TXN_TO_ENTITY_MAPPING.set_upstream(bq_create_TXN_TO_ENTITY_MAPPING)
wait_for_bq_write_TXN_TO_ENTITY_MAPPING.set_upstream(bq_write_TXN_TO_ENTITY_MAPPING)
bq_write_TXN_TO_ENTITY_MAPPING_2.set_upstream(wait_for_bq_write_TXN_TO_ENTITY_MAPPING)
wait_for_bq_write_TXN_TO_ENTITY_MAPPING_2.set_upstream(bq_write_TXN_TO_ENTITY_MAPPING_2)

bq_create_FACT_TXN_LINEITEMS_APEX_XCENTER.set_upstream(wait_for_bq_write_TXN_TO_ENTITY_MAPPING_2)
bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER.set_upstream(bq_create_FACT_TXN_LINEITEMS_APEX_XCENTER)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER.set_upstream(bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER)
bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER_2.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER_2.set_upstream(bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER_2)

bq_create_FACT_TXN_LINEITEMS_APEX_HYBRIS.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_XCENTER_2)
bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS.set_upstream(bq_create_FACT_TXN_LINEITEMS_APEX_HYBRIS)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS.set_upstream(bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS)
bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS_2.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS_2.set_upstream(bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS_2)

bq_create_FACT_TXN_LINEITEMS_NON_PHYS.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_HYBRIS_2)
bq_write_FACT_TXN_LINEITEMS_NON_PHYS.set_upstream(bq_create_FACT_TXN_LINEITEMS_NON_PHYS)
wait_for_bq_write_FACT_TXN_LINEITEMS_NON_PHYS.set_upstream(bq_write_FACT_TXN_LINEITEMS_NON_PHYS)
bq_write_FACT_TXN_LINEITEMS_NON_PHYS_2.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_NON_PHYS)
wait_for_bq_write_FACT_TXN_LINEITEMS_NON_PHYS_2.set_upstream(bq_write_FACT_TXN_LINEITEMS_NON_PHYS_2)

bq_create_FACT_TXN_LINEITEMS_APEX_JOINED.set_upstream(bq_write_FACT_TXN_LINEITEMS_NON_PHYS_2)
bq_write_FACT_TXN_LINEITEMS_APEX_JOINED.set_upstream(bq_create_FACT_TXN_LINEITEMS_APEX_JOINED)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_JOINED.set_upstream(bq_write_FACT_TXN_LINEITEMS_APEX_JOINED)
bq_write_FACT_TXN_LINEITEMS_APEX_JOINED_2.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_JOINED)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_JOINED_2.set_upstream(bq_write_FACT_TXN_LINEITEMS_APEX_JOINED_2)

bq_create_FACT_TXN_LINEITEMS_APEX_WISH.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_JOINED_2)
bq_write_FACT_TXN_LINEITEMS_APEX_WISH.set_upstream(bq_create_FACT_TXN_LINEITEMS_APEX_WISH)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH.set_upstream(bq_write_FACT_TXN_LINEITEMS_APEX_WISH)
bq_write_FACT_TXN_LINEITEMS_APEX_WISH_2.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH_2.set_upstream(bq_write_FACT_TXN_LINEITEMS_APEX_WISH_2)

bq_create_FACT_TXN_LINEITEMS_APEX_WISH_JOINED.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH_2)
bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED.set_upstream(bq_create_FACT_TXN_LINEITEMS_APEX_WISH_JOINED)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED.set_upstream(bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED)
bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED_2.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED)
wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED_2.set_upstream(bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED_2)

bq_create_FACT_TXN_LINEITEM.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEMS_APEX_WISH_JOINED_2)
bq_write_FACT_TXN_LINEITEM.set_upstream(bq_create_FACT_TXN_LINEITEM)
wait_for_bq_write_FACT_TXN_LINEITEM.set_upstream(bq_write_FACT_TXN_LINEITEM)
bq_write_FACT_TXN_LINEITEM_2.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEM)
wait_for_bq_write_FACT_TXN_LINEITEM_2.set_upstream(bq_write_FACT_TXN_LINEITEM_2)

bq_create_FACT_TXN.set_upstream(wait_for_bq_write_FACT_TXN_LINEITEM_2)
bq_write_FACT_TXN.set_upstream(bq_create_FACT_TXN)
wait_for_bq_write_FACT_TXN.set_upstream(bq_write_FACT_TXN)
bq_write_FACT_TXN_2.set_upstream(wait_for_bq_write_FACT_TXN)
wait_for_bq_write_FACT_TXN_2.set_upstream(bq_write_FACT_TXN_2)

bq_create_DIM_DATE.set_upstream(wait_for_bq_write_FACT_TXN_2)
bq_write_DIM_DATE.set_upstream(bq_create_DIM_DATE)
wait_for_bq_write_DIM_DATE.set_upstream(bq_write_DIM_DATE)
bq_write_DIM_DATE_2.set_upstream(wait_for_bq_write_DIM_DATE)
wait_for_bq_write_DIM_DATE_2.set_upstream(bq_write_DIM_DATE_2)

bq_create_DIM_STORE.set_upstream(wait_for_bq_write_DIM_DATE_2)
bq_write_DIM_STORE.set_upstream(bq_create_DIM_STORE)
wait_for_bq_write_DIM_STORE.set_upstream(bq_write_DIM_STORE)
bq_write_DIM_STORE_2.set_upstream(wait_for_bq_write_DIM_STORE)
wait_for_bq_write_DIM_STORE_2.set_upstream(bq_write_DIM_STORE_2)

bq_create_DIM_LOYALTY_ACCT.set_upstream(wait_for_bq_write_DIM_STORE_2)
bq_write_DIM_LOYALTY_ACCT.set_upstream(bq_create_DIM_LOYALTY_ACCT)
wait_for_bq_write_DIM_LOYALTY_ACCT.set_upstream(bq_write_DIM_LOYALTY_ACCT)
