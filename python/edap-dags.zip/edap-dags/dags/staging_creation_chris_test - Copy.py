import json
import os
from airflow import DAG
import yaml
from airflow.contrib.operators.gcs_download_operator import GoogleCloudStorageDownloadOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.sensors import ExternalTaskSensor

from twm_plugin import (
    BigQueryOperator,
    BigQueryCreateEmptyTableOperator)
from UDF import utils
from datetime import timedelta
from airflow.configuration import expand_env_var

from twm_plugin.sensors.bigquery_job_sensor import BigQueryJobSensor


def create_staging_schema(**context):
    """
        Accepts task context which contains the existing schema of a table in JSON format
        Appends the additional CDC columns used in the staging tables
        Overwrites the XCOM variable with the modified schema
    :param context:
    """
    existing_table_schema = context["task_instance"].xcom_pull(
        task_ids='gcs_download_schema_' + context["params"]["source_table"], key='TABLE_SCHEMA')
    table_schema = json.loads(existing_table_schema.decode('utf-8'))
    # append start date to track insertion
    table_schema.append({
        "mode": "REQUIRED",
        "name": "cdc_start_date",
        "type": "DATE"
        })
    # append end date to track when record became stale
    table_schema.append({
        "mode": "NULLABLE",
        "name": "cdc_end_date",
        "type": "DATE"
        })
    # append flag to track which record is current
    table_schema.append({
        "mode": "REQUIRED",
        "name": "current_flag",
        "type": "BOOL"
        })

    context["task_instance"].xcom_push(key='TABLE_SCHEMA', value=table_schema)


def task_factory(dag, task_name, task_yaml, szone_acls):
    """
        Create TWM custom Airflow tasks from yaml configuration
    """
    # Options that apply for all tasks
    source_table = task_yaml['source_table']
    primary_keys = task_yaml['primary_keys']
    primary_keys_string = ''
    for i, key in enumerate(primary_keys):
        primary_keys_string += ''' AND t.''' + key + ''' = s.''' + key

    dest_type = task_yaml['dest_type']

    DEV_BUCKET = 'edap-dev'
    PROD_BUCKET = 'edap-prod'
    PROD_PROJECT = 'twm-edap-prod-1802'
    DEV_PROJECT = 'twm-edap-dev-1802'
    ENV = ''
    PROJECT = ''
    dest_bucket = ''
    # Environment Setup
    if 'ENV' not in os.environ:
        ENV = expand_env_var('development')
        PROJECT = DEV_PROJECT
        dest_bucket = DEV_BUCKET
    else:
        ENV = expand_env_var(os.environ['ENV'])
        if ENV == 'production':
            PROJECT = PROD_PROJECT
            dest_bucket = PROD_BUCKET
        else:
            PROJECT = DEV_PROJECT
            dest_bucket = DEV_BUCKET

    # Options specific for this operator
    dest_area = task_yaml['dest_area']
    dest_szone = task_yaml['dest_szone']
    dest_sourcesys = task_yaml['dest_sourcesys']
    dest_dataset = task_yaml['dest_dataset']
    dest_export_format = task_yaml['dest_export_format']
    skip_backfill = task_yaml.get('skip_backfill', False)

    # Compose schema file name based on configuration
    schema = utils.datalake_schema(
        dest_area,
        dest_szone,
        dest_sourcesys,
        dest_dataset,
        dest_export_format)

    wait_for_raw = ExternalTaskSensor(
        task_id='wait_for_raw_' + source_table + '_table_load',
        external_dag_id=dag_name + '-raw',
        external_task_id='bq_raw_load_' + source_table,
        execution_delta=None,  # Same day as today
        poke_interval=60,
        pool='staging_sensor_pool',
        dag=dag)
    gcs_download_schema = GoogleCloudStorageDownloadOperator(
        task_id='gcs_download_schema_' + source_table,
        google_cloud_storage_conn_id='gcs',
        bucket=dest_bucket,
        object=utils.datalake_path(dest_area, dest_sourcesys, dest_szone, dest_dataset) + utils.schema_filename(dest_dataset),
        store_to_xcom_key='TABLE_SCHEMA',
        dag=dag
    )
    gcs_create_staging_schema = PythonOperator(
        task_id='gcs_create_staging_schema_' + source_table,
        provide_context=True,
        python_callable=create_staging_schema,
        params={"source_table": source_table},
        dag=dag
    )
    bq_create_empty_staging_table = BigQueryCreateEmptyTableOperator(
        task_id='bq_create_empty_staging_table_' + source_table,
        project_id=PROJECT,
        dataset_id='staging',
        table_id=dest_sourcesys + '_' + dest_dataset,
        schema_fields='{{ ti.xcom_pull(task_ids="gcs_create_staging_schema_' + source_table + '", key="TABLE_SCHEMA") }}',
        bigquery_conn_id='gbq',
        time_partitioning={'field': 'JOB_RUN_DATE'},
        dag=dag
    )
    bq_write_to_staging = BigQueryOperator(
        task_id='bq_write_to_staging_' + source_table,
        bigquery_conn_id='gbq',
        use_legacy_sql=False,
        write_disposition='WRITE_APPEND',
        allow_large_results=True,
        time_partitioning={"field": 'JOB_RUN_DATE'},
        bql='''
            SELECT
            CAST("{{ ds }}" as DATE) as cdc_start_date,
            CAST(NULL as DATE) as cdc_end_date,
            True as current_flag,
            t.*
            FROM `''' + PROJECT + '''.raw.''' + dest_sourcesys + '_' + dest_dataset + '''` t
            WHERE
                t.JOB_RUN_DATE = CAST("{{ ds }}" as DATE)
            ''',
        destination_dataset_table=PROJECT + '.staging_chris.' + dest_sourcesys + '_' + dest_dataset,
        store_to_xcom_key='STAGING_WRITE_JOB_ID',
        check_job_status=False,
        schema_object=schema,
        dag=dag
    )
    wait_for_bq_write = BigQueryJobSensor(
        task_id='wait_for_bq_write_' + source_table,
        project_id=PROJECT,
        bigquery_conn_id='gbq',
        job_id='{{ ti.xcom_pull(task_ids="bq_write_to_staging_' + source_table + '", key="STAGING_WRITE_JOB_ID") }}',
    )
    if not skip_backfill:
        bq_backfill_updated_records = BigQueryOperator(
            task_id='bq_backfill_updated_records_' + source_table,
            bigquery_conn_id='gbq',
            use_legacy_sql=False,
            write_disposition='WRITE_APPEND',
            allow_large_results=True,
            wait_for_downstream=True,
            time_partitioning={"field": 'JOB_RUN_DATE'},
            bql='''
                SELECT
                CASE
                  WHEN cdc_end_date IS NOT NULL THEN cdc_end_date
                  ELSE CAST("{{ ds }}" as DATE)
                END AS cdc_end_date,
                CAST("{{ ds }}" as DATE) as JOB_RUN_DATE,
                False AS current_flag,
                t.* EXCEPT (JOB_RUN_DATE, cdc_end_date, current_flag)
                FROM `''' + PROJECT + '''.staging_chris.''' + dest_sourcesys + '_' + dest_dataset + '''` t
                WHERE
                    t.JOB_RUN_DATE = CAST("{{ yesterday_ds }}" as DATE)
                    AND EXISTS
                    (SELECT * FROM `''' + PROJECT + '''.staging_chris.''' + dest_sourcesys + '_' + dest_dataset + '''` s
                        WHERE s.JOB_RUN_DATE = CAST("{{ ds }}" as DATE) ''' + primary_keys_string +
                    ''' AND s.cdc_start_date != t.cdc_start_date''' +
                ''' ) ''',
            destination_dataset_table=PROJECT + '.staging_chris.' + dest_sourcesys + '_' + dest_dataset,
            store_to_xcom_key='STAGING_BACKFILL_UPDATED_JOB_ID',
            check_job_status=False,
            dag=dag
        )
        wait_for_bq_updated_backfill = BigQueryJobSensor(
            task_id='wait_for_bq_updated_backfill_' + source_table,
            project_id=PROJECT,
            bigquery_conn_id='gbq',
            wait_for_downstream=True,
            job_id='{{ ti.xcom_pull(task_ids="bq_backfill_updated_records_' + source_table + '", key="STAGING_BACKFILL_UPDATED_JOB_ID") }}',
        )
        if dag.catchup:
            bq_backfill_non_updated_records = BigQueryOperator(
                task_id='bq_backfill_non_updated_records_' + source_table,
                bigquery_conn_id='gbq',
                use_legacy_sql=False,
                write_disposition='WRITE_APPEND',
                allow_large_results=True,
                wait_for_downstream=True,
                time_partitioning={"field": 'JOB_RUN_DATE'},
                bql='''
                    SELECT
                    CAST("{{ ds }}" as DATE) as JOB_RUN_DATE,
                    t.* EXCEPT (JOB_RUN_DATE)
                    FROM `''' + PROJECT + '''.staging_chris.''' + dest_sourcesys + '_' + dest_dataset + '''` t
                    WHERE
                        t.JOB_RUN_DATE = CAST("{{ yesterday_ds }}" as DATE)
                        AND NOT EXISTS
                        (SELECT * FROM `''' + PROJECT + '''.staging_chris.''' + dest_sourcesys + '_' + dest_dataset + '''` s
                            WHERE s.JOB_RUN_DATE = CAST("{{ ds }}" as DATE) ''' + primary_keys_string +
                        ''' AND s.cdc_start_date = t.cdc_start_date''' +
                        ''' ) ''',
                destination_dataset_table=PROJECT + '.staging_chris.' + dest_sourcesys + '_' + dest_dataset,
                store_to_xcom_key='STAGING_BACKFILL_NON_UPDATED_JOB_ID',
                check_job_status=False,
                dag=dag
            )
            wait_for_bq_non_updated_backfill = BigQueryJobSensor(
                task_id='wait_for_bq_non_updated_backfill_' + source_table,
                project_id=PROJECT,
                bigquery_conn_id='gbq',
                job_id='{{ ti.xcom_pull(task_ids="bq_backfill_non_updated_records_' + source_table + '", key="STAGING_BACKFILL_NON_UPDATED_JOB_ID") }}',
            )
        # NOTE: Commenting out for now for diagnostic reasons.
        # if ENV == 'production':
        #     bq_cleanup_old_partitions = BigQueryOperator(
        #         task_id='bq_backfill_non_updated_records',
        #         bigquery_conn_id='gbq',
        #         use_legacy_sql=False,
        #         write_disposition='WRITE_APPEND',
        #         allow_large_results=True,
        #         time_partitioning={"field": 'JOB_RUN_DATE'},
        #         bql='''
        #             DELETE FROM
        #                 `''' + PROJECT + '''.staging_chris.''' + dest_sourcesys + '_' + dest_dataset + '''` t
        #             WHERE
        #                 t.JOB_RUN_DATE < CAST("{{ yesterday_ds }}" as DATE)''',
        #         destination_dataset_table=PROJECT + '.staging_chris.' + dest_sourcesys + '_' + dest_dataset,
        #         dag=dag
        #     )

    if skip_backfill and dag.catchup:
        bq_invalidate_historical_records = BigQueryOperator(
            task_id='bq_invalidate_historical_records_' + source_table,
            bigquery_conn_id='gbq',
            use_legacy_sql=False,
            write_disposition='WRITE_APPEND',
            allow_large_results=True,
            wait_for_downstream=True,
            bql='''
            UPDATE `''' + PROJECT + '''.staging_chris.''' + dest_sourcesys + '_' + dest_dataset + '''` t
            SET t.current_flag = FALSE
            WHERE
            t.current_flag = TRUE
            AND
            t.JOB_RUN_DATE < CAST("{{ ds }}" as DATE)
            AND EXISTS
            (SELECT * FROM `''' + PROJECT + '''.staging_chris.''' + dest_sourcesys + '_' + dest_dataset + '''` s
                WHERE s.JOB_RUN_DATE = CAST("{{ ds }}" as DATE) ''' + primary_keys_string +
            ''' ) ''',
            dag=dag
        )

    # Wait for the RAW load DAGs to complete
    gcs_download_schema.set_upstream(wait_for_raw)
    # Always make sure the BQ schema update task depends on the schema download task
    gcs_create_staging_schema.set_upstream(gcs_download_schema)
    # Always make sure the BQ create staging table task depends on the create staging schema task
    bq_create_empty_staging_table.set_upstream(gcs_create_staging_schema)
    # CLear the partition we are about to insert data into, in case of previously failed task
    # bq_clear_partition.set_upstream(bq_create_empty_staging_table)
    # Always make sure the BQ staging write task depends on the gcs_create_staging_schema`
    bq_write_to_staging.set_upstream(bq_create_empty_staging_table)
    # Wait for the BQ job to finish
    wait_for_bq_write.set_upstream(bq_write_to_staging)

    if not skip_backfill:
        # Backfill the old version of records that have been updated
        bq_backfill_updated_records.set_upstream(wait_for_bq_write)
        # Wait for the BQ job to finish
        wait_for_bq_updated_backfill.set_upstream(bq_backfill_updated_records)
        # Only run the backfill task if the table is incremental (catchup = true)
        if dag.catchup:
            bq_backfill_non_updated_records.set_upstream(wait_for_bq_updated_backfill)
            wait_for_bq_non_updated_backfill.set_upstream(bq_backfill_non_updated_records)
        # if ENV == 'production':
            # bq_cleanup_old_partitions.set_upstream(wait_for_bq_updated_backfill)
    if skip_backfill and dag.catchup:
        bq_invalidate_historical_records.set_upstream(wait_for_bq_write)


def map_to_task(dag, task_name, task_yaml, szone_acls):
    """
    Create an Airflow Task object from yaml configuration
    """
    new_task = task_factory(dag, task_name, task_yaml, szone_acls)
    return new_task


def map_to_dag(dag_name, dag_yaml, szone_acls):
    """
        Create an Airflow DAG object from yaml configuration file
    """
    description = dag_yaml.get('description', "")
    schedule_interval = dag_yaml.get('schedule_interval', "")
    if 'staging_start_date' in dag_yaml:
        start_date = dag_yaml.get('staging_start_date', "")
    else:
        start_date = dag_yaml.get('start_date', "")
    end_date = dag_yaml.get('end_date', "")
    catchup = dag_yaml.get('catchup', False)
    max_active_dags = 32

    default_args = {
        'owner': 'airflow',
        'depends_on_past': False,
        'retries': 3,
        'retry_delay': timedelta(minutes=3),
    }

    if end_date != "":
        dag = DAG(
            dag_name + '-staging-chris-test',
            description=description,
            schedule_interval=schedule_interval,
            start_date=start_date,
            end_date=end_date,
            catchup=catchup,
            max_active_runs=max_active_dags,
            default_args=default_args)
    else:
        dag = DAG(
            dag_name + '-staging-chris-test',
            description=description,
            schedule_interval=schedule_interval,
            start_date=start_date,
            catchup=catchup,
            max_active_runs=max_active_dags,
            default_args=default_args)

    # Iterate through the sub-items on a DAG and create tasks
    for task_name in dag_yaml["tasks"]:
        map_to_task(dag, task_name, dag_yaml["tasks"][task_name], szone_acls)
    return dag


# Load yaml file
if 'AIRFLOW_HOME' not in os.environ:
    AIRFLOW_HOME = expand_env_var('~/airflow')
else:
    AIRFLOW_HOME = expand_env_var(os.environ['AIRFLOW_HOME'])

AIRFLOW_DAGS_FOLDER = AIRFLOW_HOME + '/dags'

# Read configuration file for ACLs
szones_config_file = open(AIRFLOW_DAGS_FOLDER + '/twm_ingestion_szones.yaml')
szone_acls = utils.read_config(szones_config_file)

# Read configuration file for DAGs
DIRECTORY = AIRFLOW_DAGS_FOLDER + '/sources'
yaml_string = ''
# loop through all files in the sources dir
for filename in os.listdir(AIRFLOW_DAGS_FOLDER + '/sources'):
    if "hybris-catch-up" in filename:
        with open(DIRECTORY + '/' + filename, "r") as infile:
            # append them to the dags file object
            yaml_string += infile.read()
ingestion_dags = yaml.load(yaml_string)

# Iterate through the first level and create DAGs
if ingestion_dags:
    for dag_name in ingestion_dags:
        dag = map_to_dag(dag_name, ingestion_dags[dag_name], szone_acls)
        globals()[dag_name] = dag
