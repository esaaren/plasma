--for each table, look at raw table
    --for each partition
    -- insert from partition into master table for that partition
        --whatever records in the new incremental raw

---mock data
UPDATE `twm-edap-dev-1802.devraw.apx_item_approval_chris_test` set partition_date = CAST('2018-06-27' as DATE)
WHERE item_approval_key in ('9199465', '14795701','15723723','13242909','108938','99455','101305')

---
--- insert from incremental table to raw_master
insert into raw_master
    select from devraw.apx_item_approval_chris_test where partition = 'date'

--- insert from source to fill in what's not in incremental
insert into raw_master
    select 'date' as partition_date, s.* from raw_master s
    WHERE partition_date = 'date - 1'
    AND some_key is not in
        (select * from raw_master where partition_date = 'date')
