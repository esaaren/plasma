# -*- coding: utf-8 -*-
#

import sys
import json

from twm_plugin.hooks.gcs_hook import TWM_GoogleCloudStorageHook
from twm_plugin.hooks.twm_mssql_hook import TWM_MsSqlHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from decimal import Decimal
from tempfile import NamedTemporaryFile
from six import string_types
import unicodecsv as csv

PY3 = sys.version_info[0] == 3


class TWM_MsSqlToGoogleCloudStorageOperator(BaseOperator):
    """
    Copy data from Microsoft SQL Server to Google cloud storage in JSON
    or CSV format.
    """
    template_fields = ('sql', 'bucket', 'filename',
                       'schema_filename', 'schema')
    template_ext = ('.sql',)
    ui_color = '#ededed'

    @apply_defaults
    def __init__(self,
                 sql,
                 bucket,
                 filename,
                 schema_filename=None,
                 metadata_filename=None,
                 approx_max_file_size_bytes=1900000000,
                 mssql_conn_id='mssql_default',
                 google_cloud_storage_conn_id='google_cloud_storage_default',
                 schema=None,
                 delegate_to=None,
                 acls=None,
                 export_format={'file_format': 'json'},
                 *args,
                 **kwargs):
        """
        :param sql: The SQL to execute on the SQL Server table.
        :type sql: string
        :param bucket: The bucket to upload to.
        :type bucket: string
        :param filename: The filename to use as the object name when uploading
            to Google cloud storage.
            The following keys can be used for filename replacement:
            * file_no: should be specified to allow the operator to inject
                       file numbers in cases where the file is split due to
                       size.
            * job_id: can be used to replace with the task job id
            * exec_date: can be used to replace with the execution date
        :type filename: string
        :param schema_filename: If set, the filename to use as the object name
            when uploading a .json file containing the BigQuery schema fields
            for the table that was dumped from SQL Server.
        :type schema_filename: string
        :param approx_max_file_size_bytes: This operator supports the ability
            to split large table dumps into multiple files (see notes in the
            filenamed param docs above). Google cloud storage allows for files
            to be a maximum of 4GB. This param allows developers to specify the
            file size of the splits.
        :type approx_max_file_size_bytes: long
        :param mssql_conn_id: Reference to a specific SQL Server hook.
        :type mssql_conn_id: string
        :param google_cloud_storage_conn_id: Reference to a specific Google
            cloud storage hook.
        :type google_cloud_storage_conn_id: string
        :param schema: The schema to use, if any. Should be a list of dict or
            a str. Examples could be see: https://cloud.google.com/bigquery
            /docs/schemas#specifying_a_json_schema_file
        :type schema: str or list
        :param delegate_to: The account to impersonate, if any. For this to
            work, the service account making the request must have domain-wide
            delegation enabled.
        :type delegate_to: str
        :param acls: list of role-entity pairs
            The entity holding the permission has to be in one of the
            following forms:
            # - user-userId
            # - user-email
            # - group-groupId
            # - group-email
            # - domain-domain
            # - project-team-projectId
            # - allUsers
            # - allAuthenticatedUsers Examples:
            # - The user liz@example.com would be user-liz@example.com.
            # - The group example@googlegroups.com would be
            #       group-example@googlegroups.com.
            # - To refer to all members of the Google Apps for Business
            #       domain example.com, the entity would be domain-example.com.
            The role has to be one of the following:
            # - reader
            # - writer
            # - owner
        :type acls: list
        :param export_format: Details for files to be exported into GCS.
            Allows to specify 'json' or 'csv', and also addiitional details for
            CSV file exports (quotes, separators, etc.)
            This is a dict with the following key-value pairs:
              * file_format: 'json' or 'csv'. If using CSV, more details can
                              be added
              * csv_dialect: preconfigured set of CSV export parameters
                             (i.e.: 'excel', 'excel-tab', 'unix_dialect').
                             If present, will ignore all other 'csv_' options.
                             See https://docs.python.org/3/library/csv.html
              * csv_delimiter: A one-character string used to separate fields.
                               It defaults to ','.
              * csv_doublequote: If doublequote is False and no escapechar is
                                 set, Error is raised if a quotechar is found
                                 in a field.
                                 It defaults to True.
              * csv_escapechar: A one-character string used to escape the
                                delimiter if quoting is set to QUOTE_NONE
                                and the quotechar if doublequote is False.
                                It defaults to None, which disables escaping.
              * csv_lineterminator: The string used to terminate lines.
                                    It defaults to '\r\n'.
              * csv_quotechar: A one-character string used to quote fields
                                containing special characters, such as
                                the delimiter or quotechar, or which
                                contain new-line characters.
                                It defaults to '"'.
              * csv_quoting: Controls when quotes should be generated.
                             It can take on any of the QUOTE_* constants
                             Defaults to csv.QUOTE_MINIMAL.
                             Valid values are:
                             'csv.QUOTE_ALL': Quote all fields
                             'csv.QUOTE_MINIMAL': only quote those fields
                                                  which contain special
                                                  characters such as delimiter,
                                                  quotechar or any of the
                                                  characters in lineterminator.
                             'csv.QUOTE_NONNUMERIC': Quote all non-numeric
                                                     fields.
                             'csv.QUOTE_NONE': never quote fields. When the
                                               current delimiter occurs in
                                               output data it is preceded
                                               by the current escapechar
                                               character. If escapechar
                                               is not set, the writer
                                               will raise Error if any
                                               characters that require
                                               escaping are encountered.
              * csv_columnheader: If True, first row in the file will
                                  include column names. Defaults to False.
            :type export_format: list
        """
        super(TWM_MsSqlToGoogleCloudStorageOperator,
              self).__init__(*args, **kwargs)
        self.sql = sql
        self.bucket = bucket
        self.filename = filename
        self.schema_filename = schema_filename
        self.approx_max_file_size_bytes = approx_max_file_size_bytes
        self.mssql_conn_id = mssql_conn_id
        self.google_cloud_storage_conn_id = google_cloud_storage_conn_id
        self.schema = schema
        self.delegate_to = delegate_to
        self.export_format = export_format
        self.rows_transferred = 0
        self.metadata_filename = metadata_filename
        self.acls = acls

    def execute(self, context):
        # self.log.info('Executing: %s', self.sql)
        self.context = context

        try:
            conn = self._query_mssql()
            cursor = conn.cursor()
            cursor.execute(self.sql)
            files_to_upload = self._write_local_data_files(cursor)

            # If a schema is set, create a BQ schema JSON file.
            if self.schema_filename:
                files_to_upload.update(self._write_local_schema_file(cursor))

            if self.metadata_filename:
                files_to_upload.update(self._write_local_metadata_file())

            # Flush all files before uploading
            for file_handle in files_to_upload.values():
                file_handle.flush()

            self._upload_to_gcs(files_to_upload)
        finally:
            # Close all temp file handles.
            for file_handle in files_to_upload.values():
                file_handle.close()
            # Close open connection
            conn.commit()
            conn.close()

    def _query_mssql(self):
        """
        Queries mssql and returns a cursor to the results.
        """
        mssql = TWM_MsSqlHook(mssql_conn_id=self.mssql_conn_id)
        conn = mssql.get_conn()
        return conn

    def _write_local_data_files(self, cursor):
        """
        Takes a cursor, and writes results to a local file.

        :return: A dictionary where keys are filenames to be used as object
            names in GCS, and values are file handles to local files that
            contain the data for the GCS objects.
        """
        schema = list(
            map(lambda schema_tuple: schema_tuple[0], cursor.description))
        file_no = 0
        tmp_file_handle = NamedTemporaryFile(delete=True)
        tmp_file_handles = {self.filename.format(
            file_no=format(file_no, '04d'),
            job_id=self.context['task_instance'].job_id.zfill(5),
            exec_date=self.context['task_instance'].execution_date.
            strftime('%Y%m%d')
        ):
            tmp_file_handle}

        # Save file header for csv if required
        if(self.export_format['file_format'] == 'csv'):

            # Deal with CSV formatting. Try to use dialect if passed
            if('csv_dialect' in self.export_format):
                # Use dialect name from params
                dialect_name = self.export_format['csv_dialect']
            else:
                # Create internal dialect based on parameters passed
                dialect_name = 'mssql_to_gcs'
                # TODO: The parameter for the function are not working
                # TODO: need to fix them
                csv.register_dialect(dialect_name,
                                     delimiter="|",
                                     doublequote=False,
                                     escapechar='"',
                                     lineterminator=self.export_format.get(
                                         'csv_lineterminator') or
                                     '\r\n',
                                     quotechar=self.export_format.get(
                                         'csv_quotechar') or '"',
                                     quoting=eval(self.export_format.get(
                                         'csv_quoting') or
                                         'csv.QUOTE_ALL'))
            # Create CSV writer using either provided or generated dialect
            csv_writer = csv.writer(tmp_file_handle,
                                    encoding='utf-8',
                                    dialect=dialect_name)

            # Include column header in first row
            if('csv_columnheader' in self.export_format and
                    eval(self.export_format['csv_columnheader'])):
                csv_writer.writerow(schema)
            rows_transferred = 0
        for row in cursor:
            # Convert datetimes and longs to BigQuery safe types
            row = map(self.convert_types, row)

            # Save rows as CSV
            if(self.export_format['file_format'] == 'csv'):
                csv_writer.writerow(list(row))
            # Save rows as JSON
            else:
                # Convert datetime objects to utc seconds,
                # and decimals to floats
                row_dict = dict(zip(schema, row))

                # TODO validate that row isn't > 2MB. BQ enforces
                # a hard row size of 2MB.
                s = json.dumps(row_dict, sort_keys=True)
                if PY3:
                    s = s.encode('utf-8')
                tmp_file_handle.write(s)

                # Append newline to make dumps BigQuery compatible.
                tmp_file_handle.write(b'\n')

            # Stop if the file exceeds the file size limit.
            if tmp_file_handle.tell() >= self.approx_max_file_size_bytes:
                file_no += 1
                tmp_file_handle = NamedTemporaryFile(delete=True)
                tmp_file_handles[self.filename.format(
                    file_no)] = tmp_file_handle

                # For CSV files, weed to create a new writer with the new
                # handle and write header in first row
                if(self.export_format['file_format'] == 'csv'):
                    csv_writer = csv.writer(tmp_file_handle,
                                            encoding='utf-8',
                                            dialect=dialect_name)
                    if('csv_columnheader' in self.export_format and
                            eval(self.export_format['csv_columnheader'])):
                        csv_writer.writerow(schema)
            rows_transferred += 1

        self.rows_transferred = rows_transferred
        # self.log.info('Processed %s rows', rows_transferred)

        return tmp_file_handles

    def _write_local_schema_file(self, cursor):
        """
        Takes a cursor, and writes the BigQuery schema for the results to a
        local file system.

        :return: A dictionary where key is a filename to be used as an object
            name in GCS, and values are file handles to local files that
            contains the BigQuery schema fields in .json format.
        """
        schema = []
        tmp_schema_file_handle = NamedTemporaryFile(delete=True)

        # Update schema file name
        self.schema_filename = self.schema_filename.format(
            job_id=self.context['task_instance'].job_id.zfill(5),
            exec_date=self.context['task_instance'].execution_date.
            strftime('%Y%m%d'))

        if self.schema is not None and isinstance(self.schema, string_types):
            schema = self.schema
            tmp_schema_file_handle.write(schema)
        else:
            if self.schema is not None and isinstance(self.schema, list):
                schema = self.schema
            else:
                for field in cursor.description:
                    # See PEP 249 for details about the description tuple.
                    field_name = field[0]
                    field_type = self.type_map(field[1].__name__.lower())
                    if field[6] or field_type == 'TIMESTAMP':
                        field_mode = 'NULLABLE'
                    else:
                        # field_mode = 'REQUIRED' #Set all fields to NULLABLE
                        # as there are REQUIRED issues with sip-apex
                        field_mode = 'NULLABLE'
                    # TODO: need to avoid hard coding this.
                    if field_name == 'JOB_RUN_DATE':
                        field_type = 'DATE'
                    schema.append({
                        'name': field_name,
                        'type': field_type,
                        'mode': field_mode,
                    })
                self.schema = schema
            s = json.dumps(schema, tmp_schema_file_handle, sort_keys=True)
            if PY3:
                s = s.encode('utf-8')
            tmp_schema_file_handle.write(s)

        # self.log.info('Using schema for %s: %s', self.schema_filename,
        # schema)
        return {self.schema_filename: tmp_schema_file_handle}

    def _write_local_metadata_file(self):
        """
        Writes a metadata file to the local filesystem.

        :return: A dictionary where key is a filename to be used as an object
            name in GCS, and values are file handles to local files that
            contains the metadata in .json format.
        """
        tmp_metadata_file_handle = NamedTemporaryFile(delete=True)
        # Update metadata file name
        self.metadata_filename = self.metadata_filename.format(
            job_id=self.context['task_instance'].job_id.zfill(5),
            exec_date=self.context['task_instance'].execution_date.
            strftime('%Y%m%d'))
        metadata = {
            'bq_schema':
                json.dumps(self.schema, sort_keys=True),
            'airflow_task_instance':
                {
                    'job_id':
                        self.context['task_instance'].job_id,
                    'task_id':
                        self.context['task_instance'].task_id,
                    'dag_id':
                        self.context['task_instance'].dag_id,
                    'execution_date':
                        self.context['task_instance'].execution_date
                        .strftime("%Y-%m-%d %H:%M:%S"),
                    'start_date':
                        self.context['task_instance'].start_date
                        .strftime("%Y-%m-%d %H:%M:%S")
                },
            'rows_transferred':
                self.rows_transferred
        }

        s = json.dumps(
            metadata,
            tmp_metadata_file_handle,
            sort_keys=True
        )

        if PY3:
            s = s.encode('utf-8')
        tmp_metadata_file_handle.write(s)
        # self.log.info('Using metadata for %s: %s', self.metadata_filename,
        #              metadata)
        return {self.metadata_filename: tmp_metadata_file_handle}

    def _upload_to_gcs(self, files_to_upload):
        """
        Upload all of the file splits (and optionally the schema .json file) to
        Google cloud storage.
        """
        # Compose mime_type using file format passed as param
        mime_type = 'application/' + self.export_format['file_format']

        # Add custom metadata with airflow information, acls, and row-count
        req_body = {
            'metadata': {
                'airflow-job-id':
                    self.context['task_instance'].job_id.zfill(5),
                'bq-schema':
                    json.dumps(self.schema)
            },
            'acl': self.acls
        }

        hook = TWM_GoogleCloudStorageHook(
            google_cloud_storage_conn_id=self.google_cloud_storage_conn_id,
            delegate_to=self.delegate_to)
        for object, tmp_file_handle in files_to_upload.items():
            hook.upload(self.bucket, object, tmp_file_handle.name, mime_type,
                        body=req_body)

    @classmethod
    def convert_types(cls, value):
        """
        Takes a value from MySQLdb, and converts it to a value that's safe for
        JSON/Google cloud storage/BigQuery. Dates are converted to UTC seconds.
        Decimals are converted to floats.
        """
        # if type(value) in (datetime, date):
        #     return time.mktime(value.timetuple())
        if isinstance(value, Decimal):
            return float(value)
        else:
            return value

    @classmethod
    def type_map(cls, mssql_type):
        """
        Helper function that maps from MsSQL fields to BigQuery fields. Used
        when a schema_filename is set.
        """
        d = {
            'int': 'INT64',
            'long': 'INT64',
            'float': 'FLOAT64',
            'bool': 'BOOL',
            'datetime': 'DATETIME',
            'decimal': 'FLOAT64'
        }
        return d[mssql_type] if mssql_type in d else 'STRING'
