import os
import csv
import pandas
import copy
from sys import maxsize
from datetime import datetime
from tempfile import NamedTemporaryFile
from airflow.operators.python_operator import PythonOperator
from airflow.utils.decorators import apply_defaults


class SfmcTranformPythonOperator(PythonOperator):

    template_fields = ['path_to_csv', 'path_to_write_csv', 'datetime']

    @apply_defaults
    def __init__(
            self,
            path_to_csv,
            path_to_write_csv,
            columns_to_ignore,
            current_encoding,
            datetime,
            *args,
            **kwargs):
        """
        Create a new SfmcTranformPythonOperator. Note that both
        dataflow_default_options and options will be merged to specify pipeline
        execution parameter, and dataflow_default_options is expected to save
        high-level options, for instances, project and zone information, which
        apply to all dataflow operators in the DAG.

        :param path_to_csv: Path to cs to csv file for the data
        :type path_to_csv: string
        :param path_to_write_csv: Where the new file is going
        :type path_to_write_csv: string
        :param columns_to_ignore: Map of job specific columns_to_ignore.
        :type columns_to_ignore: list
        :param current_encoding: The encoding that file comes in as
        :type current_encoding: string
        :param datetime: The execution date of the current airflow job.
        :type datetime: string
        """

        super(PythonOperator, self).__init__(*args, **kwargs)

        self.path_to_csv = path_to_csv
        self.path_to_write_csv = path_to_write_csv
        self.columns_to_ignore = columns_to_ignore
        self.current_encoding = current_encoding
        self.datetime = datetime

    def execute(self, context):
        """Execute the job."""
        current_delimiter = '|'
        expected_delimiter = '|'
        quote_char = '"'
        date_format = '%m/%d/%Y'
        date_format_with_dashes = '%m-%d-%Y'  # 04-08-2016
        datetime_format = '%m/%d/%Y %I:%M:%S %p'
        excess_datetime_format = '%Y-%m-%d %H:%M:%S.%f'
        run_once = True
        tmp_new_file = NamedTemporaryFile(delete=True)
        csv.field_size_limit(maxsize)

        tmp_new_file = self.path_to_csv + "escape_quotes.csv"
        with open(self.path_to_csv, "r", encoding=self.current_encoding) as source_file, open(tmp_new_file, "w", encoding='utf-8') as dest_file:
            # as far as I can tell, the only solution to the unescaped double quotes is to preprocess the file
            # and escape any quote besides the first one, last one, ones by commas/whitespace
            for line in source_file:
                error = False
                current_idx = 0
                number_of_replacements = 0
                new_line = copy.deepcopy(line)
                linecount = len(line.rstrip('\r\n')) - 1
                for character in line:
                    if character == quote_char:
                        if (current_idx != 0) and (current_idx != linecount) and not (line[current_idx - 1] == current_delimiter or line[current_idx + 1] == current_delimiter):
                            new_line = new_line[0:current_idx + number_of_replacements] + "\\" + line[current_idx:]
                            number_of_replacements = number_of_replacements + 1
                            error = True
                    current_idx = current_idx + 1
                if not error:
                    dest_file.write(line)
                else:
                    dest_file.write(new_line)
        source_file.close
        dest_file.close

        with open(tmp_new_file, "r", encoding="utf-8") as source_file, open(self.path_to_write_csv, "a", encoding='utf-8') as dest_file:
            chunksize = 10000  # number of rows to load at a time
            text_file_reader = pandas.read_csv(
                source_file, delimiter=current_delimiter, quoting=csv.QUOTE_ALL, encoding="utf-8", escapechar='\\', engine="python", chunksize=chunksize)

            for dataframe in text_file_reader:
                # detect and correct malformed Dates and DateTimes
                row_count = 0
                for row in dataframe.itertuples(index=False):
                    items = list(row)
                    col_count = 0
                    for value in items:
                        try:
                            date_obj = datetime.strptime(str(value), date_format)
                            if date_obj:
                                dataframe.iat[row_count, col_count] = date_obj.date()
                        except ValueError:
                            pass
                        try:
                            date_obj = datetime.strptime(str(value), date_format_with_dashes)
                            if date_obj:
                                dataframe.iat[row_count, col_count] = date_obj.date()
                        except ValueError:
                            pass
                        try:
                            datetime_obj = datetime.strptime(str(value), datetime_format)
                            if datetime_obj:
                                dataframe.iat[row_count, col_count] = datetime_obj
                        except ValueError:
                            pass

                        try:
                            if len(str(value)) == 29:
                                value = value[:-3]
                                datetime_obj = datetime.strptime(str(value), excess_datetime_format)
                                if datetime_obj:
                                    dataframe.iat[row_count, col_count] = datetime_obj
                        except ValueError:
                            pass

                        col_count = col_count + 1
                    row_count = row_count + 1

                # build up list of values and append as extra column
                dataframe.insert(0, "JOB_RUN_DATE", [self.datetime] * row_count, allow_duplicates=True)

                # drop any columns specified in columns_to_ignore
                # this is necessary as some tables contain extra columns in the incremental load used to diff the table
                if self.columns_to_ignore:
                    columns_to_drop = []
                    for column in self.columns_to_ignore:
                        if column in dataframe.columns:  # sanity check that column name is valid
                            columns_to_drop.append(column)
                    if columns_to_drop:
                        dataframe = dataframe.drop(columns=columns_to_drop)

                headers = False
                if run_once:
                    headers = dataframe.columns.values
                    run_once = False

                dataframe.to_csv(dest_file, encoding="utf-8", sep=expected_delimiter, escapechar='"', index=False, mode="a", quoting=csv.QUOTE_ALL, line_terminator='\r\n', header=headers)
        source_file.closed
        dest_file.closed
        os.remove(tmp_new_file)
