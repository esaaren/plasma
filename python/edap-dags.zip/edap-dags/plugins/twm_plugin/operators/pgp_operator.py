from airflow.models import BaseOperator
import gnupg
import os


class TWM_PGPEncryptOperator(BaseOperator):

    template_fields = ('src_unencrypted_file_location',
                       'recipients_fingerprint',
                       'dest_encrypted_file_location',
                       'gnupg_home')

    def __init__(self,
                 src_unencrypted_file_location,
                 recipients_fingerprint,
                 dest_encrypted_file_location,
                 gnupg_home='',
                 *args,
                 **kwargs):
        super(TWM_PGPEncryptOperator, self).__init__(*args, **kwargs)
        self.gnupg_home = gnupg_home
        self.src_unencrypted_file_location = src_unencrypted_file_location
        self.recipients_fingerprint = recipients_fingerprint
        self.dest_encrypted_file_location = dest_encrypted_file_location

    def execute(self, context):
        self.log.info(
            'PGPEncryptOperator - Setting GNUPG Home to ' + self.gnupg_home)
        # Create GPG object with access to keys in keyring
        gpg = gnupg.GPG(gnupghome=self.gnupg_home)

        # Read unencrypted file data
        self.log.info('PGPEncryptOperator - Reading unecyrpted file from ' +
                      self.src_unencrypted_file_location)
        with open(self.src_unencrypted_file_location, mode='rb') as unecrypted_file:
            self.log.info('PGPEncryptOperator - Writing encrypted file for ' +
                          self.recipients_fingerprint + ' to file ' + self.dest_encrypted_file_location)
            status = gpg.encrypt_file(
                unecrypted_file,
                recipients=self.recipients_fingerprint,
                output=self.dest_encrypted_file_location
            )
            self.log.info('PGPEncryptOperator - Encryption output status OK: ' + str(
                status.ok) + ' - status : ' + status.status + ' - stderr: ' + status.stderr)


class TWM_PGPDecryptOperator(BaseOperator):

    template_fields = ('src_encrypted_file_location',
                       'dest_decrypted_file_location',
                       'passphrase',
                       'gnupg_home')

    def __init__(self,
                 src_encrypted_file_location,
                 dest_decrypted_file_location,
                 passphrase,
                 gnupg_home='',
                 *args,
                 **kwargs):
        super(TWM_PGPDecryptOperator, self).__init__(*args, **kwargs)
        self.gnupg_home = gnupg_home
        self.src_encrypted_file_location = src_encrypted_file_location
        self.dest_decrypted_file_location = dest_decrypted_file_location
        self.passphrase = passphrase

    def execute(self, context):
        self.log.info(
            'PGPDecryptOperator - Setting GNUPG Home to ' + self.gnupg_home)
        # Create GPG object with access to keys in keyring
        gpg = gnupg.GPG(gnupghome=self.gnupg_home)
        self.log.info('PGPDecryptOperator - Reading encrypted file from  ' +
                      self.src_encrypted_file_location)
        # Read encrypted file data (mode read/binary)
        with open(self.src_encrypted_file_location, mode='rb') as encrypted_file:
            self.log.info('PGPDecryptOperator - Writing decrypted file to ' +
                          self.dest_decrypted_file_location)
            # Decrypt data and write file
            status = gpg.decrypt_file(
                encrypted_file, passphrase=self.passphrase, output=self.dest_decrypted_file_location)
            self.log.info('PGPDecryptOperator - Decryption output status OK: ' + str(
                status.ok) + ' - status: ' + status.status + ' - stderr: ' + status.stderr)
