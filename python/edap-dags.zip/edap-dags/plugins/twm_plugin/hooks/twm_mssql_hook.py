# -*- coding: utf-8 -*-
#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
import pyodbc

from airflow.hooks.dbapi_hook import DbApiHook


class TWM_MsSqlHook(DbApiHook):
    """
    Interact with Microsoft SQL Server.
    """

    conn_name_attr = 'mssql_conn_id'
    default_conn_name = 'mssql_default'
    supports_autocommit = True

    def __init__(self, *args, **kwargs):
        super(TWM_MsSqlHook, self).__init__(*args, **kwargs)
        self.schema = kwargs.pop("schema", None)

    def get_conn(self):
        """
        Returns a mssql connection object
        """
        conn = self.get_connection(self.mssql_conn_id)
        # TODO: Maybe not hardcode the driver so we can specify later but we would need to add to the DbApi_hook I think.
        driver = "ODBC Driver 17 for SQL Server"
        host = conn.host
        schema = self.schema or conn.schema
        login = conn.login
        password = conn.password
        port = str(conn.port)
        connect_string = "DRIVER=" + chr(123) + driver + chr(125) + ";SERVER=" + host + ";Database=" + schema + ";UID=" + login + ";PWD=" + password + ";PORT=" + port + ";"
        conn = pyodbc.connect(connect_string)
        return conn
