from airflow.contrib.hooks.gcs_hook import GoogleCloudStorageHook
from apiclient.http import MediaFileUpload
from googleapiclient import errors


class TWM_GoogleCloudStorageHook(GoogleCloudStorageHook):

    # pylint:disable=redefined-builtin
    def upload(self, bucket, object, filename,
               mime_type='application/octet-stream', body=None):
        """
        Uploads a local file to Google Cloud Storage.

        :param bucket: The bucket to upload to.
        :type bucket: string
        :param object: The object name to set when uploading the local file.
        :type object: string
        :param filename: The local file path to the file to be uploaded.
        :type filename: string
        :param mime_type: The MIME type to set when uploading the file.
        :type mime_type: string
        :param body: Request body sent to the object insert to GCS
        :type body: dict
        """
        # self.log.info('Uploading: %s', filename)
        service = self.get_conn()
        media = MediaFileUpload(filename, mime_type)
        service \
            .objects() \
            .insert(
                bucket=bucket,
                name=object,
                media_body=media,
                body=body) \
            .execute()

    def compose_folder(self, destination_bucket, destination_object,
                       prefix=None):
        """
        Concatenates a list of existing objects into a new object in the same
        bucket.

        :param destination_bucket: The name of the bucket in which to store the
            new object
        :type destination_bucket: string
        :param destination_object: The name of the new object.
        :type destination_object: string
        :param prefix: Filter results to objects whose names begin with this
            prefix.
        :type prefix: string
        """
        # service = self.get_conn()

        try:
            # Retrieve a list of objects whose names begin with the specified
            # prefix.
            # response = service.objects().list(
            #     bucket=destination_bucket,
            #     prefix=prefix
            # ).execute()
            # body = {'sourceObjects': response['items']}

            ids = super(TWM_GoogleCloudStorageHook, self).list(
                bucket=destination_bucket, prefix=prefix)
            body = {'sourceObjects': []}
            for name in ids:
                body['sourceObjects'].append({'name': name})

            # Concatenate the list of objects into a new object.
            self.compose(destination_bucket, destination_object, body)

            return True

        except errors.HttpError as ex:
            if ex.resp['status'] == '404':
                return False
            raise

    def compose(self, destination_bucket, destination_object,
                body=None):
        """
        Concatenates a list of existing objects into a new object in the same
        bucket.

        :param destination_bucket: The destination of the object to copied to.
            Can be omitted; then the same bucket is used.
        :type destination_bucket: string
        :param destination_object: The (renamed) path of the object if given.
        :type destination_object: string
        :param body: Request body containing the objects to be concatenated.
        :type body: dict
        """

        service = self.get_conn()
        try:
            service.objects().compose(
                destinationBucket=destination_bucket,
                destinationObject=destination_object,
                body=body
            ).execute()

            return True

        except errors.HttpError as ex:
            if ex.resp['status'] == '404':
                return False
            raise

    def delete_files(self, bucket, prefix):
        """
        Deletes a list of existing objects from the specified bucket.

        :param bucket: The name of the bucket from which to delete the objects.
        :type bucket: string
        :param prefix: Filter results to objects whose names begin with this
            prefix.
        :type prefix: string
        """

        if prefix is not None:
            try:
                # Retrieve a list of objects whose names begin with the specified
                # prefix.
                ids = super(TWM_GoogleCloudStorageHook, self).list(
                    bucket=bucket, prefix=prefix)
                for name in ids:
                    super(TWM_GoogleCloudStorageHook,
                          self).delete(bucket=bucket, object=name)

                return True

            except errors.HttpError as ex:
                if ex.resp['status'] == '404':
                    return False
                raise
