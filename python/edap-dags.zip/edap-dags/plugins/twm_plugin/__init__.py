from airflow.plugins_manager import AirflowPlugin
from twm_plugin.operators.mysql_to_gcs import\
    TWM_MySqlToGoogleCloudStorageOperator
from twm_plugin.operators.mssql_to_gcs import\
    TWM_MsSqlToGoogleCloudStorageOperator
from twm_plugin.operators.twm_mssql_operator import\
    TWM_MsSqlOperator
from twm_plugin.operators.twm_gcs_to_bq import\
    TWM_GoogleCloudStorageToBigQueryOperator
from twm_plugin.operators.twm_bigquery_operator import BigQueryOperator
from twm_plugin.operators.twm_bigquery_operator import BigQueryCreateEmptyTableOperator
from twm_plugin.hooks.twm_bigquery_hook import BigQueryHook
from twm_plugin.hooks.twm_mssql_hook import TWM_MsSqlHook
from twm_plugin.hooks.twm_gcp_api_base_hook import GoogleCloudBaseHook


class TWM_Plugin(AirflowPlugin):
    name = "twm_plugin"
    operators = [
        TWM_MySqlToGoogleCloudStorageOperator,
        TWM_MsSqlToGoogleCloudStorageOperator,
        TWM_MsSqlOperator,
        TWM_GoogleCloudStorageToBigQueryOperator,
        BigQueryOperator,
        BigQueryCreateEmptyTableOperator]

    hooks = [
        BigQueryHook,
        GoogleCloudBaseHook,
        TWM_MsSqlHook]

    executors = []
    macros = []
    admin_views = []
    flask_blueprints = []
    menu_links = []
