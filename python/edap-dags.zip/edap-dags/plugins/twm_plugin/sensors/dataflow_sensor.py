from twm_plugin.sensors.base_sensor_operator import BaseSensorOperator
from twm_plugin.hooks.gcp_dataflow_hook import TWM_DataFlowHook
from airflow.utils.decorators import apply_defaults
from airflow import AirflowException


class DataflowJobSensor(BaseSensorOperator):

    template_fields = ['job_name']
    ui_color = '#f0eee4'

    @apply_defaults
    def __init__(
            self,
            project,
            location,
            job_name,
            gcp_conn_id='google_cloud_default',
            delegate_to=None,
            *args,
            **kwargs):
        super(DataflowJobSensor, self).__init__(*args, **kwargs)
        self.project = project
        self.job_location = location
        self.job_name = job_name
        self.gcp_conn_id = gcp_conn_id

    def poke(self, context):
        self.log.info('Sensor checks completion status of : %s',
                      self.job_name)
        hook = TWM_DataFlowHook(
            gcp_conn_id=self.gcp_conn_id, delegate_to=None, poll_sleep=10)
        state = hook.check_dataflow_job_status(
            project=self.project, location=self.job_location,
            job_name=self.job_name
        )
        self.log.info(
            "Job Name: %s has status: %s", self.job_name, state
        )
        if state == 'JOB_STATE_DONE':
            return True
        elif state == 'JOB_STATE_FAILED' or state == 'JOB_STATE_CANCELLED':
            raise AirflowException(
                "Dataflow job did not finish successfully: " + state
            )
        return False
