from twm_plugin.sensors.base_sensor_operator import BaseSensorOperator
from twm_plugin.hooks.twm_bigquery_hook import BigQueryHook
from airflow.utils.decorators import apply_defaults


class BigQueryJobSensor(BaseSensorOperator):
    """
    Checks for the status of a job in Google Bigquery.
        :param project_id: The Google cloud project in which to look for the table.
            The connection supplied to the hook must provide
            access to the specified project.
        :type project_id: string
        :param bigquery_conn_id: The connection ID to use when connecting to
            Google BigQuery.
        :type bigquery_conn_id: string
        :param job_id: The name/ID of the job to check
        :type job_id: string
        :param delegate_to: The account to impersonate, if any.
            For this to work, the service account making the request must
            have domain-wide delegation enabled.
        :type delegate_to: string
    """
    template_fields = ('project_id', 'job_id')
    ui_color = '#f0eee4'

    @apply_defaults
    def __init__(self,
                 project_id,
                 job_id,
                 bigquery_conn_id='bigquery_default_conn',
                 delegate_to=None,
                 *args, **kwargs):

        super(BigQueryJobSensor, self).__init__(*args, **kwargs)
        self.project_id = project_id
        self.bigquery_conn_id = bigquery_conn_id
        self.job_id = job_id
        self.delegate_to = delegate_to

    def poke(self, context):
        # Use the hook to check if job has finished
        self.log.info('Sensor checking for status of job: %s', self.job_id)
        hook = BigQueryHook(
            bigquery_conn_id=self.bigquery_conn_id,
            delegate_to=self.delegate_to)

        conn = hook.get_conn()
        cursor = conn.cursor()
        return cursor.poll_job_complete(job_id=self.job_id)
